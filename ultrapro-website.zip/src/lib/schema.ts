import { z } from "zod";
import { normalizePhone } from "./phone";
import { PANEL_KEYS, panelErrors, type PanelKey } from "./panels";

const text = (max: number) => z.string().trim().max(max, `Keep this under ${max} characters.`);
const optionalText = (max: number) => text(max).optional().default("");

export const phoneField = z
  .string()
  .trim()
  .superRefine((v, ctx) => {
    const r = normalizePhone(v);
    if (!r.valid) ctx.addIssue({ code: "custom", message: r.reason });
  });

const optionalPhone = z
  .string()
  .trim()
  .superRefine((v, ctx) => {
    if (!v) return;
    const r = normalizePhone(v);
    if (!r.valid) ctx.addIssue({ code: "custom", message: r.reason });
  })
  .optional()
  .default("");

export const panelSchema = z.object({
  mode: z.enum(["custom", "repeat", "designer", "blank", "same_diff_layout"]),
  sourcePanel: z.enum(["front", "back", "left", "right", ""]).optional().default(""),
  exactText: optionalText(1500),
  phone: optionalText(60),
  address: optionalText(500),
  social: optionalText(300),
  qr: optionalText(500),
  logoPlacement: optionalText(300),
  notes: optionalText(2000),
  layoutByDesigner: z.boolean().optional().default(false),
});

export const assetSchema = z.object({
  key: z.string().max(80),
  label: z.string().max(120),
  fileName: z.string().max(200),
  size: z.number().int().nonnegative().max(50 * 1024 * 1024),
  type: z.string().max(100),
  status: z.literal("selected-on-device-not-uploaded"),
});

export const formSchema = z
  .object({
    brand: z.object({
      brandName: text(120).min(1, "Enter your shop or brand name."),
      contactName: text(120).min(1, "Enter the contact person's name."),
      contactPhone: phoneField,
      alternatePhone: optionalPhone,
      preferredContact: z.enum(["whatsapp", "call", "both"]),
      shopAddress: optionalText(500),
      tagline: optionalText(200),
      email: z
        .string()
        .trim()
        .max(200)
        .refine((v) => v === "" || z.string().email().safeParse(v).success, "Enter a valid email or leave it empty.")
        .optional()
        .default(""),
      social: optionalText(300),
      useContactOnBag: z.boolean(),
      printPhone: optionalPhone,
      printOn: z.object({
        logo: z.boolean(),
        phone: z.boolean(),
        address: z.boolean(),
        tagline: z.boolean(),
        email: z.boolean(),
        social: z.boolean(),
      }),
    }),
    bag: z.object({
      sizeUnknown: z.boolean(),
      width: z.string().trim().max(12).optional().default(""),
      height: z.string().trim().max(12).optional().default(""),
      depth: z.string().trim().max(12).optional().default(""),
      unit: z.enum(["in", "cm"]),
      backgroundColor: optionalText(100),
      printColors: optionalText(200),
      extraInstructions: optionalText(1500),
    }),
    panels: z.object({
      front: panelSchema,
      back: panelSchema,
      left: panelSchema,
      right: panelSchema,
    }),
    instructions: z.object({
      written: optionalText(8000),
      designerDecidesLayout: z.boolean(),
      hasAudio: z.boolean(),
      audioSeconds: z.number().int().min(0).max(60 * 30).optional().default(0),
      audioMime: z.string().max(80).optional().default(""),
    }),
    assets: z.array(assetSchema).max(30).optional().default([]),
    consent: z.literal(true, { errorMap: () => ({ message: "Please tick the box to continue." }) }),
    /** honeypot — must stay empty */
    website: z.string().max(0).optional().default(""),
    /** random UUID created per draft; used to prevent duplicates */
    clientKey: z.string().min(16).max(80),
    startedAt: z.number().int().optional().default(0),
  })
  .superRefine((v, ctx) => {
    // --- bag size
    if (!v.bag.sizeUnknown) {
      (["width", "height", "depth"] as const).forEach((dim) => {
        const raw = v.bag[dim];
        const n = Number(raw);
        if (!raw || !Number.isFinite(n) || n <= 0 || n > 500) {
          ctx.addIssue({ code: "custom", path: ["bag", dim], message: "Enter a number greater than 0, or tick “I don't know my bag size”." });
        }
      });
    }
    // --- printing number
    if (!v.brand.useContactOnBag && v.brand.printOn.phone && !v.brand.printPhone) {
      ctx.addIssue({ code: "custom", path: ["brand", "printPhone"], message: "Enter the number to print, or tick “Use my contact number on the bag”." });
    }
    // --- panels
    const errs = panelErrors(v.panels as never);
    for (const key of PANEL_KEYS) {
      const msg = errs[key as PanelKey];
      if (msg) ctx.addIssue({ code: "custom", path: ["panels", key, "sourcePanel"], message: msg });
    }
  });

export type FormInput = z.input<typeof formSchema>;
export type FormValues = z.output<typeof formSchema>;

/** Step -> field paths, used for per-step validation in React Hook Form. */
export const STEP_FIELDS: Record<number, string[]> = {
  1: [
    "brand.brandName", "brand.contactName", "brand.contactPhone", "brand.alternatePhone", "brand.email",
    "brand.printPhone", "brand.preferredContact",
  ],
  2: ["bag.width", "bag.height", "bag.depth", "bag.unit"],
  3: ["panels"],
  4: ["instructions.written"],
  5: ["consent"],
};

export function hasPanelContent(p: FormValues["panels"][PanelKey]) {
  return Boolean(p.exactText || p.phone || p.address || p.social || p.qr || p.logoPlacement || p.notes);
}
