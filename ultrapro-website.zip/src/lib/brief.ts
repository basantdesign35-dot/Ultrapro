import { PANEL_KEYS, PANEL_LABEL, MODE_LABEL, resolveSource, isReference, type PanelKey, type PanelMode } from "./panels";
import type { RequestRecord } from "./record";

type P = RequestRecord["panels"][PanelKey];

export interface PanelBrief {
  key: PanelKey;
  title: string;
  mode: PanelMode;
  modeLabel: string;
  /** "client" = written by client, "designer" = left to designer, "pending" = needs confirmation, "blank" */
  origin: "client" | "designer" | "pending" | "blank";
  headline: string;
  lines: { label: string; value: string }[];
  note?: string;
}

function contentLines(p: P): { label: string; value: string }[] {
  const rows: [string, string][] = [
    ["Exact text to print", p.exactText],
    ["Phone number", p.phone],
    ["Address", p.address],
    ["Social media", p.social],
    ["QR code", p.qr],
    ["Logo placement", p.logoPlacement],
    ["Notes", p.notes],
  ];
  return rows.filter(([, v]) => v).map(([label, value]) => ({ label, value }));
}

export function panelBrief(rec: RequestRecord, key: PanelKey): PanelBrief {
  const p = rec.panels[key];
  const base = { key, title: PANEL_LABEL[key].toUpperCase(), mode: p.mode, modeLabel: MODE_LABEL[p.mode] };

  if (p.mode === "blank") return { ...base, origin: "blank", headline: "Leave this panel blank.", lines: [] };

  if (isReference(p.mode)) {
    const src = resolveSource(rec.panels as never, key);
    const direct = p.sourcePanel as PanelKey;
    if (!src) return { ...base, origin: "pending", headline: "References another panel, but the reference is invalid.", lines: [], note: "Confirm with the client." };
    const sp = rec.panels[src];
    const via = direct !== src ? ` (via ${PANEL_LABEL[direct].toUpperCase()})` : "";
    const same = p.mode === "same_diff_layout";
    const headline = same
      ? `Use the same content as ${PANEL_LABEL[src].toUpperCase()}${via}, but with a different layout.`
      : `Repeat ${PANEL_LABEL[src].toUpperCase()}${via}.`;
    if (sp.mode === "designer") {
      return { ...base, origin: "designer", headline, lines: contentLines(sp), note: `${PANEL_LABEL[src]} is Designer's Choice, so this panel follows the designer's decision.` };
    }
    if (sp.mode === "blank") return { ...base, origin: "blank", headline, lines: [], note: `${PANEL_LABEL[src]} is blank.` };
    return { ...base, origin: "client", headline, lines: contentLines(sp), note: sp.notes && same ? undefined : undefined };
  }

  if (p.mode === "designer") {
    return {
      ...base,
      origin: "designer",
      headline: "Designer decides the layout and creative elements.",
      lines: contentLines(p),
      note: contentLines(p).length ? "Details above are mandatory client information. Do not invent others." : "No business details were given for this panel. Do not invent any.",
    };
  }
  const lines = contentLines(p);
  return {
    ...base,
    origin: "client",
    headline: p.layoutByDesigner ? "Client content provided. Layout is left to the designer." : "Custom content from the client.",
    lines,
    note: lines.length ? undefined : "Marked as custom, but no details were entered. Ask the client.",
  };
}

export function bagSizeText(rec: RequestRecord) {
  const b = rec.bagSpecifications;
  if (b.sizeStatus === "pending_confirmation" || b.width == null) return "Pending confirmation";
  return `${b.width} × ${b.height} × ${b.depth} ${b.unit === "in" ? "in" : "cm"} (W × H × D)`;
}

/** Everything that is missing / still to be confirmed, in plain language. */
export function pendingItems(rec: RequestRecord, audience: "designer" | "client" = "designer"): string[] {
  const out: string[] = [];
  if (rec.bagSpecifications.sizeStatus === "pending_confirmation") out.push("Bag size is not known. Confirm with the client.");
  if (!rec.bagSpecifications.backgroundColor) out.push("Bag background colour not specified.");
  if (!rec.bagSpecifications.printColors) out.push("Printing colours not specified.");
  for (const k of PANEL_KEYS) {
    const b = panelBrief(rec, k);
    if (b.origin === "pending") out.push(`${PANEL_LABEL[k]}: ${b.note ?? b.headline}`);
    if (rec.panels[k].mode === "custom" && b.lines.length === 0) out.push(`${PANEL_LABEL[k]}: custom content selected but no details given.`);
  }
  const hasLogo = rec.assetMetadata.some((a) => a.key === "brand-logo");
  if (rec.clientDetails.printOnBag.logo && !hasLogo) out.push("Logo was not attached. Ask the client to send it.");
  if (audience === "client") return out;
  if (rec.audio.recordedByClient) out.push(`Client recorded a voice note (${rec.audio.seconds}s). It is NOT stored in this system. Ask the client to send it on WhatsApp.`);
  if (rec.assetMetadata.length) out.push(`${rec.assetMetadata.length} file(s) were selected by the client but NOT uploaded. Ask the client to send them.`);
  return out;
}

export function submissionText(rec: RequestRecord): string {
  const L: string[] = [];
  L.push(`REQUEST ${rec.requestId}`);
  L.push(`Brand: ${rec.brandName}`);
  L.push(`Contact: ${rec.contactName} · ${rec.contactPhone}${rec.alternatePhone ? ` · alt ${rec.alternatePhone}` : ""} · prefers ${rec.preferredContact}`);
  L.push(`Bag size: ${bagSizeText(rec)}`);
  L.push(`Background colour: ${rec.bagSpecifications.backgroundColor || "-"} | Print colours: ${rec.bagSpecifications.printColors || "-"}`);
  if (rec.bagSpecifications.extraInstructions) L.push(`Size/printing notes: ${rec.bagSpecifications.extraInstructions}`);
  L.push("");
  for (const k of PANEL_KEYS) {
    const b = panelBrief(rec, k);
    L.push(`${b.title} — ${b.modeLabel}`);
    L.push(`  ${b.headline}`);
    b.lines.forEach((l) => L.push(`  ${l.label}: ${l.value}`));
    if (b.note) L.push(`  (${b.note})`);
  }
  L.push("");
  L.push(`Written instructions: ${rec.writtenInstructions || "-"}`);
  L.push(`Let the designer decide layout: ${rec.designerDecidesLayout ? "yes" : "no"}`);
  L.push(`Voice recording: ${rec.audio.recordedByClient ? `yes (${rec.audio.seconds}s), not delivered through this form` : "none"}`);
  L.push(`Files selected: ${rec.assetMetadata.length ? rec.assetMetadata.map((a) => a.fileName).join(", ") + " (not delivered through this form)" : "none"}`);
  return L.join("\n");
}
