"use client";
import { useSyncExternalStore } from "react";
import { attachments } from "./attachments";

export function useAttachments() {
  return useSyncExternalStore(attachments.subscribe, attachments.getSnapshot, attachments.getServerSnapshot);
}
