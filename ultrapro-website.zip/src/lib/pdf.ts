"use client";
import { jsPDF } from "jspdf";
import { PANEL_KEYS } from "./panels";
import { bagSizeText, panelBrief, pendingItems } from "./brief";
import type { RequestRecord } from "./record";

const BLUE: [number, number, number] = [21, 88, 171];
const TAG: Record<string, { label: string; rgb: [number, number, number] }> = {
  client: { label: "CLIENT-PROVIDED", rgb: [21, 88, 171] },
  designer: { label: "DESIGNER'S CHOICE", rgb: [124, 58, 237] },
  pending: { label: "PENDING CONFIRMATION", rgb: [180, 83, 9] },
  blank: { label: "BLANK", rgb: [100, 116, 139] },
};

// jsPDF's built-in fonts cover Latin text only. Anything else (e.g. Devanagari) cannot be drawn.
const UNSUPPORTED = /[^\u0000-\u00ff\u2013\u2014\u2018\u2019\u201c\u201d\u2022\u2026\u20ac]/g;

export function pdfCanRender(rec: RequestRecord): boolean {
  return !UNSUPPORTED.test(JSON.stringify(rec).replace(/\\u[0-9a-f]{4}/gi, ""));
}

export function buildBriefPdf(rec: RequestRecord): { blob: Blob; name: string; replacedChars: boolean } {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = 210, M = 15, CW = W - M * 2;
  let y = M;
  let replaced = false;
  const clean = (s: string) => (s ?? "").replace(UNSUPPORTED, () => { replaced = true; return "?"; });

  const ensure = (h: number) => { if (y + h > 285) { doc.addPage(); y = M; } };
  const text = (s: string, size = 10, bold = false, color: [number, number, number] = [20, 33, 61], indent = 0) => {
    doc.setFont("helvetica", bold ? "bold" : "normal").setFontSize(size).setTextColor(...color);
    const lines = doc.splitTextToSize(clean(s), CW - indent) as string[];
    lines.forEach((ln) => { ensure(size * 0.45 + 1.5); doc.text(ln, M + indent, y + size * 0.35); y += size * 0.42 + 1.4; });
  };
  const rule = () => { ensure(4); doc.setDrawColor(227, 231, 238).line(M, y, W - M, y); y += 3; };
  const heading = (s: string) => { y += 2; ensure(10); text(s, 12, true, BLUE); rule(); };
  const kv = (k: string, v: string) => { text(`${k}: ${v || "-"}`, 10, false, [20, 33, 61]); };
  const tag = (kind: keyof typeof TAG) => {
    const t = TAG[kind];
    ensure(7);
    doc.setFont("helvetica", "bold").setFontSize(8);
    const w = doc.getTextWidth(t.label) + 4;
    doc.setFillColor(...t.rgb).roundedRect(M, y, w, 5, 1, 1, "F");
    doc.setTextColor(255, 255, 255).text(t.label, M + 2, y + 3.5);
    y += 7;
  };

  // header
  doc.setFont("helvetica", "bold").setFontSize(20).setTextColor(...BLUE).text("ULTRAPRO", M, y + 6);
  doc.setFont("helvetica", "normal").setFontSize(10).setTextColor(100, 116, 139).text("Paper Bag Company", M, y + 11);
  y += 18;
  text("PAPER BAG DESIGN BRIEF", 16, true);
  rule();

  kv("Request ID", rec.requestId);
  kv("Submission date", rec.createdAt ? new Date(rec.createdAt).toLocaleString("en-IN") : "-");

  heading("Client contact");
  kv("Brand", rec.brandName);
  kv("Contact person", rec.contactName);
  kv("Phone / WhatsApp", rec.contactPhone);
  kv("Alternate number", rec.alternatePhone);
  kv("Preferred contact", rec.preferredContact);
  kv("Email", rec.clientDetails.email);
  kv("Address", rec.clientDetails.shopAddress);
  kv("Tagline", rec.clientDetails.tagline);
  kv("Social / website", rec.clientDetails.social);
  kv("Number to print on bag", rec.clientDetails.printPhone);
  kv("Print on bag", Object.entries(rec.clientDetails.printOnBag).filter(([, v]) => v).map(([k]) => k).join(", "));

  heading("Bag specifications");
  tag(rec.bagSpecifications.sizeStatus === "pending_confirmation" ? "pending" : "client");
  kv("Size", bagSizeText(rec));
  kv("Background colour", rec.bagSpecifications.backgroundColor);
  kv("Printing colours", rec.bagSpecifications.printColors);
  kv("Size / printing notes", rec.bagSpecifications.extraInstructions);

  heading("Panel instructions");
  for (const k of PANEL_KEYS) {
    const b = panelBrief(rec, k);
    ensure(24);
    text(`${b.title}  -  ${b.modeLabel}`, 11, true);
    tag(b.origin);
    text(b.headline, 10);
    b.lines.forEach((l) => text(`${l.label}: ${l.value}`, 10, false, [20, 33, 61], 4));
    if (b.note) text(b.note, 9, false, [180, 83, 9], 4);
    y += 2;
  }

  heading("Written notes");
  tag("client");
  text(rec.writtenInstructions || "None", 10);
  kv("Designer decides layout", rec.designerDecidesLayout ? "Yes" : "No");

  heading("Attachments and voice");
  kv("Voice recording", rec.audio.recordedByClient ? `Client recorded ${rec.audio.seconds}s. NOT stored in the system. Ask the client to send it.` : "None");
  if (rec.assetMetadata.length === 0) text("No files selected by client.", 10);
  rec.assetMetadata.forEach((a) => text(`- ${a.label}: ${a.fileName} (${Math.round(a.size / 1024)} KB). NOT uploaded; ask the client to send it.`, 10));

  heading("Missing or pending information");
  const pend = pendingItems(rec);
  if (pend.length === 0) text("Nothing pending.", 10);
  pend.forEach((p) => text(`- ${p}`, 10));

  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i).setFont("helvetica", "normal").setFontSize(8).setTextColor(130, 140, 155);
    doc.text(`ULTRAPRO - ${rec.requestId} - page ${i} of ${pages}`, M, 292);
  }
  return { blob: doc.output("blob"), name: `ultrapro-brief-${rec.requestId}.pdf`, replacedChars: replaced };
}
