export const PANEL_KEYS = ["front", "back", "left", "right"] as const;
export type PanelKey = (typeof PANEL_KEYS)[number];
export type PanelMode = "custom" | "repeat" | "designer" | "blank" | "same_diff_layout";

export const PANEL_LABEL: Record<PanelKey, string> = {
  front: "Front",
  back: "Back",
  left: "Left",
  right: "Right",
};

export const MODE_LABEL: Record<PanelMode, string> = {
  custom: "Custom content",
  repeat: "Repeat another panel",
  designer: "Designer's choice",
  blank: "Leave blank",
  same_diff_layout: "Same content, different layout",
};

export interface PanelRef {
  mode: PanelMode;
  sourcePanel?: PanelKey | "";
}

/** Panels that reference another panel. */
export function isReference(mode: PanelMode) {
  return mode === "repeat" || mode === "same_diff_layout";
}

/**
 * Follows the chain of references starting at `start`.
 * Returns the ordered chain, and whether it is invalid (cycle / missing source / self reference).
 */
export function followChain(
  panels: Record<PanelKey, PanelRef>,
  start: PanelKey
): { chain: PanelKey[]; error: "cycle" | "missing" | null } {
  const chain: PanelKey[] = [start];
  let current = panels[start];
  while (current && isReference(current.mode)) {
    const next = current.sourcePanel;
    if (!next || !PANEL_KEYS.includes(next as PanelKey)) return { chain, error: "missing" };
    if (chain.includes(next as PanelKey)) return { chain: [...chain, next as PanelKey], error: "cycle" };
    chain.push(next as PanelKey);
    current = panels[next as PanelKey];
  }
  return { chain, error: null };
}

/** The panel whose own content is ultimately used (follows repeats). */
export function resolveSource(panels: Record<PanelKey, PanelRef>, key: PanelKey): PanelKey | null {
  const { chain, error } = followChain(panels, key);
  return error ? null : chain[chain.length - 1];
}

/** Source options that would NOT create a loop for `key`. */
export function validSources(panels: Record<PanelKey, PanelRef>, key: PanelKey): PanelKey[] {
  return PANEL_KEYS.filter((candidate) => {
    if (candidate === key) return false;
    const trial = { ...panels, [key]: { mode: "repeat", sourcePanel: candidate } } as Record<PanelKey, PanelRef>;
    return followChain(trial, key).error === null;
  });
}

/** Validation messages per panel for an arrangement. */
export function panelErrors(panels: Record<PanelKey, PanelRef>): Partial<Record<PanelKey, string>> {
  const out: Partial<Record<PanelKey, string>> = {};
  for (const key of PANEL_KEYS) {
    const p = panels[key];
    if (!isReference(p.mode)) continue;
    if (p.sourcePanel === key) {
      out[key] = "A panel cannot repeat itself.";
      continue;
    }
    const { error } = followChain(panels, key);
    if (error === "missing") out[key] = "Choose which panel to copy.";
    if (error === "cycle") out[key] = "These panels point at each other. Pick a panel that has its own content.";
  }
  return out;
}
