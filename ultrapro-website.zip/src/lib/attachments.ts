"use client";
/**
 * In-memory holder for files and recordings the client selected.
 * - Survives client-side navigation (form -> success page) but NOT a page reload.
 * - Nothing here is uploaded anywhere: Formspree Free does not accept files.
 */
export interface Attachment {
  key: string;
  label: string;
  blob: Blob;
  fileName: string;
  kind: "file" | "audio";
  seconds?: number;
}

const store = new Map<string, Attachment>();
const listeners = new Set<() => void>();
let snapshot: Attachment[] = [];

function emit() {
  snapshot = Array.from(store.values());
  listeners.forEach((l) => l());
}

export const attachments = {
  set(a: Attachment) { store.set(a.key, a); emit(); },
  remove(key: string) { store.delete(key); emit(); },
  clear() { store.clear(); emit(); },
  get(key: string) { return store.get(key); },
  subscribe(l: () => void) { listeners.add(l); return () => { listeners.delete(l); }; },
  getSnapshot() { return snapshot; },
  getServerSnapshot() { return [] as Attachment[]; },
};

export const MAX_FILE_BYTES = 10 * 1024 * 1024;
export const ALLOWED_CLIENT_TYPES = ["image/png", "image/jpeg", "image/webp", "application/pdf"];

export function validateClientFile(file: File): string | null {
  if (!ALLOWED_CLIENT_TYPES.includes(file.type)) return "Only PNG, JPG, WEBP or PDF files are accepted.";
  if (file.size > MAX_FILE_BYTES) return "This file is larger than 10 MB.";
  if (file.size === 0) return "This file is empty.";
  return null;
}

export function extFromMime(mime: string) {
  if (mime.includes("webm")) return "webm";
  if (mime.includes("mp4") || mime.includes("aac")) return "m4a";
  if (mime.includes("ogg")) return "ogg";
  if (mime.includes("wav")) return "wav";
  return "bin";
}
