import { PANEL_KEYS } from "./panels";
import { panelBrief, bagSizeText, submissionText } from "./brief";
import type { RequestRecord } from "./record";

export type SendResult = { ok: true } | { ok: false; message: string };

function panelText(rec: RequestRecord, key: (typeof PANEL_KEYS)[number]) {
  const b = panelBrief(rec, key);
  return [`${b.modeLabel}: ${b.headline}`, ...b.lines.map((l) => `${l.label}: ${l.value}`), b.note ? `(${b.note})` : ""].filter(Boolean).join("\n");
}

/** Text-only payload. Files and audio are never included: Formspree Free does not accept uploads. */
export function buildFormspreePayload(rec: RequestRecord, submittedAtIso: string) {
  return {
    _subject: `New bag design request ${rec.requestId} — ${rec.brandName}`,
    ...(rec.clientDetails.email ? { email: rec.clientDetails.email } : {}),
    request_id: rec.requestId,
    submission_date: submittedAtIso,
    client_name: rec.contactName,
    brand_name: rec.brandName,
    contact_phone: rec.contactPhone,
    alternate_number: rec.alternatePhone || "",
    preferred_contact_method: rec.preferredContact,
    number_to_print_on_bag: rec.clientDetails.printPhone || "",
    shop_address: rec.clientDetails.shopAddress || "",
    tagline: rec.clientDetails.tagline || "",
    social: rec.clientDetails.social || "",
    print_on_bag: Object.entries(rec.clientDetails.printOnBag).filter(([, v]) => v).map(([k]) => k).join(", "),
    bag_dimensions: bagSizeText(rec),
    bag_background_color: rec.bagSpecifications.backgroundColor || "",
    bag_print_colors: rec.bagSpecifications.printColors || "",
    panel_front: panelText(rec, "front"),
    panel_back: panelText(rec, "back"),
    panel_left: panelText(rec, "left"),
    panel_right: panelText(rec, "right"),
    written_instructions: rec.writtenInstructions || "",
    designer_decides_layout: rec.designerDecidesLayout ? "yes" : "no",
    additional_notes: rec.bagSpecifications.extraInstructions || "",
    voice_note: rec.audio.recordedByClient
      ? `Client recorded a ${rec.audio.seconds}s voice note. NOT delivered through this form. Client must send it separately.`
      : "none",
    asset_information: rec.assetMetadata.length
      ? rec.assetMetadata.map((a) => `${a.label}: ${a.fileName} (${Math.round(a.size / 1024)} KB) — NOT delivered through this form`).join("\n")
      : "none",
    message: submissionText(rec),
  };
}

export async function sendToFormspree(rec: RequestRecord): Promise<SendResult> {
  const endpoint = process.env.NEXT_PUBLIC_FORMSPREE_ENDPOINT;
  if (!endpoint || !/^https:\/\/formspree\.io\/f\/[A-Za-z0-9]+$/.test(endpoint)) {
    return { ok: false, message: "The request form is not configured correctly. Please contact Ultrapro." };
  }
  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(buildFormspreePayload(rec, new Date().toISOString())),
    });
    if (res.ok) return { ok: true };
    let detail = "";
    try {
      const j = await res.json();
      detail = j?.errors?.map((e: { message: string }) => e.message).join(" ") || j?.error || "";
    } catch { /* ignore */ }
    if (res.status === 429) return { ok: false, message: "Too many submissions right now. Please try again in a few minutes." };
    return { ok: false, message: detail || `The message service returned an error (${res.status}).` };
  } catch {
    return { ok: false, message: "Could not reach the message service. Check your internet connection and try again." };
  }
}
