/**
 * Phone helpers. Used on the client form, the API route and the dashboard.
 * WhatsApp links are only ever built from digits produced here.
 */
export type PhoneResult =
  | { valid: true; digits: string } // digits include country code, no "+"
  | { valid: false; reason: string };

const DEFAULT_CC = (process.env.NEXT_PUBLIC_DEFAULT_COUNTRY_CODE || "91").replace(/\D/g, "") || "91";

export function normalizePhone(input: string, defaultCountryCode: string = DEFAULT_CC): PhoneResult {
  const raw = (input ?? "").trim();
  if (!raw) return { valid: false, reason: "Enter a phone number." };
  if (/[^\d+\s\-().]/.test(raw)) return { valid: false, reason: "Use digits only (spaces, + and - are fine)." };
  const hasPlus = raw.startsWith("+") || raw.startsWith("00");
  let digits = raw.replace(/\D/g, "");
  if (raw.startsWith("00")) digits = digits.slice(2);

  if (hasPlus) {
    if (digits.length < 8 || digits.length > 15) return { valid: false, reason: "Number with country code must be 8–15 digits." };
    return { valid: true, digits };
  }
  if (defaultCountryCode === "91") {
    if (digits.length === 10 && /^[6-9]/.test(digits)) return { valid: true, digits: "91" + digits };
    if (digits.length === 11 && digits.startsWith("0") && /^[6-9]/.test(digits[1])) return { valid: true, digits: "91" + digits.slice(1) };
    if (digits.length === 12 && digits.startsWith("91") && /^[6-9]/.test(digits[2])) return { valid: true, digits };
    return { valid: false, reason: "Enter a 10-digit mobile number, or start with + and the country code." };
  }
  if (digits.length >= 8 && digits.length <= 12) return { valid: true, digits: defaultCountryCode + digits.replace(/^0+/, "") };
  return { valid: false, reason: "Enter a valid phone number." };
}

export function whatsappUrl(digits: string | undefined | null): string | null {
  if (!digits || !/^\d{8,15}$/.test(digits)) return null;
  return `https://wa.me/${digits}`;
}

export function telUrl(digits: string | undefined | null): string | null {
  if (!digits || !/^\d{8,15}$/.test(digits)) return null;
  return `tel:+${digits}`;
}
