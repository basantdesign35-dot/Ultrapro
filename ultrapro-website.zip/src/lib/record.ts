import type { FormValues } from "./schema";
import { normalizePhone } from "./phone";

/** Single place that maps validated form values to the stored request shape (used by API route AND client). */
export function toRecord(v: FormValues, requestId: string) {
  const contact = normalizePhone(v.brand.contactPhone);
  const alt = v.brand.alternatePhone ? normalizePhone(v.brand.alternatePhone) : null;
  const printPhone = v.brand.useContactOnBag ? v.brand.contactPhone : v.brand.printPhone;
  return {
    requestId,
    brandName: v.brand.brandName,
    contactName: v.brand.contactName,
    contactPhone: v.brand.contactPhone,
    contactPhoneDigits: contact.valid ? contact.digits : "",
    alternatePhone: v.brand.alternatePhone || "",
    alternatePhoneDigits: alt && alt.valid ? alt.digits : "",
    preferredContact: v.brand.preferredContact,
    clientDetails: {
      shopAddress: v.brand.shopAddress,
      tagline: v.brand.tagline,
      email: v.brand.email,
      social: v.brand.social,
      printOnBag: v.brand.printOn,
      useContactNumberOnBag: v.brand.useContactOnBag,
      printPhone: printPhone || "",
    },
    bagSpecifications: {
      sizeStatus: (v.bag.sizeUnknown ? "pending_confirmation" : "provided") as "pending_confirmation" | "provided",
      width: v.bag.sizeUnknown ? null : Number(v.bag.width),
      height: v.bag.sizeUnknown ? null : Number(v.bag.height),
      depth: v.bag.sizeUnknown ? null : Number(v.bag.depth),
      unit: v.bag.unit,
      backgroundColor: v.bag.backgroundColor,
      printColors: v.bag.printColors,
      extraInstructions: v.bag.extraInstructions,
    },
    panels: v.panels,
    writtenInstructions: v.instructions.written,
    designerDecidesLayout: v.instructions.designerDecidesLayout,
    audio: {
      recordedByClient: v.instructions.hasAudio,
      seconds: v.instructions.audioSeconds,
      mime: v.instructions.audioMime,
      stored: false as const, // Formspree Free cannot receive audio; never claim otherwise
    },
    assetMetadata: v.assets,
  };
}

export type RecordCore = ReturnType<typeof toRecord>;

export interface RequestRecord extends RecordCore {
  status: "new" | "in_progress" | "completed";
  assignedDesignerUid?: string;
  createdAt?: number;
  updatedAt?: number;
  delivery?: { formspree?: "pending" | "delivered" | "failed"; updatedAt?: number };
}
