"use client";
import JSZip from "jszip";
import { download } from "./download";
import type { Attachment } from "./attachments";
import { submissionText } from "./brief";
import type { RequestRecord } from "./record";

const safe = (s: string) => s.replace(/[^\w.\-]+/g, "_").slice(0, 80) || "file";

/** Client-side request package: summary + data + the files/recordings that stayed on the device. */
export async function buildRequestPackage(rec: RequestRecord, files: Attachment[]) {
  const zip = new JSZip();
  zip.file("request-summary.txt", submissionText(rec));
  zip.file("request-data.json", JSON.stringify(rec, null, 2));
  zip.file(
    "README.txt",
    `ULTRAPRO design request ${rec.requestId}\n\nSend this ZIP file to your Ultrapro designer (for example on WhatsApp).\n` +
      `It contains your request summary plus the files and voice recordings you selected.\n` +
      `These files were NOT uploaded by the website.\n`
  );
  const folder = zip.folder("attachments");
  files.forEach((f, i) => folder?.file(`${String(i + 1).padStart(2, "0")}-${safe(f.fileName)}`, f.blob));
  const blob = await zip.generateAsync({ type: "blob" });
  return { blob, name: `ultrapro-${rec.requestId}-package.zip` };
}

export { download };
