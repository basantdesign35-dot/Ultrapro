import { NextResponse } from "next/server";
import { createHash } from "crypto";
import { z } from "zod";
import { adminDb } from "@/lib/firebase-admin";
import { rateLimit } from "@/lib/ratelimit";
import { ServerValue } from "firebase-admin/database";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const body = z.object({
  clientKey: z.string().min(16).max(80),
  formspree: z.enum(["delivered", "failed"]),
});

/** Records whether the Formspree copy of a request was delivered. Requires the draft's secret clientKey. */
export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (!rateLimit(`delivery:${ip}`, 20, 10 * 60 * 1000).ok) {
    return NextResponse.json({ ok: false, message: "Too many attempts." }, { status: 429 });
  }
  const parsed = body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ ok: false, message: "Invalid request." }, { status: 400 });
  try {
    const db = adminDb();
    const hash = createHash("sha256").update(parsed.data.clientKey).digest("hex");
    const snap = await db.ref(`requestKeys/${hash}`).get();
    if (!snap.exists()) return NextResponse.json({ ok: false, message: "Unknown request." }, { status: 404 });
    const id = snap.val().requestId as string;
    await db.ref(`designRequests/${id}/delivery`).update({ formspree: parsed.data.formspree, updatedAt: ServerValue.TIMESTAMP });
    return NextResponse.json({ ok: true, requestId: id });
  } catch (e) {
    console.error("delivery update failed", e);
    return NextResponse.json({ ok: false, message: "Could not update delivery status." }, { status: 502 });
  }
}
