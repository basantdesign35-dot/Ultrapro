import { NextResponse } from "next/server";
import { createHash, randomBytes } from "crypto";
import { adminDb } from "@/lib/firebase-admin";
import { formSchema } from "@/lib/schema";
import { normalizePhone } from "@/lib/phone";
import { toRecord } from "@/lib/record";
import { rateLimit } from "@/lib/ratelimit";
import { ServerValue } from "firebase-admin/database";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const sha = (s: string) => createHash("sha256").update(s).digest("hex");

function clientIp(req: Request) {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || "unknown";
}

/** Removes undefined values (Firebase Admin rejects them). */
function clean<T>(v: T): T {
  return JSON.parse(JSON.stringify(v));
}

function newRequestId() {
  const d = new Date();
  const ymd = `${d.getUTCFullYear()}${String(d.getUTCMonth() + 1).padStart(2, "0")}${String(d.getUTCDate()).padStart(2, "0")}`;
  // 5 random bytes, base32-ish, no ambiguous characters
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = randomBytes(6);
  const code = Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
  return `UP-${ymd}-${code}`;
}

export async function POST(req: Request) {
  // 1. Basic abuse controls
  const ip = clientIp(req);
  const rl = rateLimit(`create:${ip}`, 6, 10 * 60 * 1000);
  if (!rl.ok) {
    return NextResponse.json(
      { ok: false, code: "rate_limited", message: `Too many attempts. Please wait ${Math.ceil(rl.retryAfterSec / 60)} minute(s) and try again.` },
      { status: 429, headers: { "Retry-After": String(rl.retryAfterSec) } }
    );
  }
  const len = Number(req.headers.get("content-length") ?? 0);
  if (len > 100_000) {
    return NextResponse.json({ ok: false, code: "too_large", message: "Request is too large." }, { status: 413 });
  }

  // 2. Parse + validate (never trust the browser)
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, code: "bad_json", message: "Invalid request." }, { status: 400 });
  }
  const parsed = formSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { ok: false, code: "invalid", message: "Some details are missing or invalid.", issues: parsed.error.issues.map((i) => ({ path: i.path.join("."), message: i.message })) },
      { status: 422 }
    );
  }
  const v = parsed.data;
  // honeypot is enforced by schema (max 0). Too-fast submissions are bots.
  if (v.startedAt && Date.now() - v.startedAt < 8000) {
    return NextResponse.json({ ok: false, code: "too_fast", message: "That was very quick. Please check your details and submit again." }, { status: 429 });
  }

  const contact = normalizePhone(v.brand.contactPhone);
  if (!contact.valid) return NextResponse.json({ ok: false, code: "invalid", message: contact.reason }, { status: 422 });

  try {
    const db = adminDb();
    const keyHash = sha(v.clientKey);
    const keyRef = db.ref(`requestKeys/${keyHash}`);

    // 3. Idempotency: same draft key => same request, no duplicate record
    const existing = await keyRef.get();
    if (existing.exists()) {
      return NextResponse.json({ ok: true, requestId: existing.val().requestId, duplicate: true });
    }

    const requestId = newRequestId();
    const record = clean({
      ...toRecord(v, requestId),
      consent: { accepted: true, at: ServerValue.TIMESTAMP },
      delivery: { formspree: "pending", updatedAt: ServerValue.TIMESTAMP },
      status: "new",
      assignedDesignerUid: "",
      createdAt: ServerValue.TIMESTAMP,
      updatedAt: ServerValue.TIMESTAMP,
    });

    // 4. Reserve the key atomically so two parallel taps cannot both create a record
    const reserve = await keyRef.transaction((cur) => (cur === null ? { requestId, createdAt: Date.now() } : undefined));
    if (!reserve.committed) {
      const again = await keyRef.get();
      return NextResponse.json({ ok: true, requestId: again.val()?.requestId, duplicate: true });
    }
    try {
      await db.ref(`designRequests/${requestId}`).set(record);
    } catch (e) {
      await keyRef.remove().catch(() => undefined); // let the client retry cleanly
      throw e;
    }
    return NextResponse.json({ ok: true, requestId });
  } catch (err) {
    console.error("create request failed", err);
    return NextResponse.json(
      { ok: false, code: "db_failed", message: "We could not save your request on our side. Nothing was sent. Please try again." },
      { status: 502 }
    );
  }
}
