import type { Metadata } from "next";
import { Suspense } from "react";
import SuccessView from "@/components/request/SuccessView";

export const metadata: Metadata = { title: "Request received" };

export default function SuccessPage() {
  return <Suspense fallback={<p className="p-6">Loading…</p>}><SuccessView /></Suspense>;
}
