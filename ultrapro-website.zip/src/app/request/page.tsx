import type { Metadata } from "next";
import Link from "next/link";
import Logo from "@/components/Logo";
import RequestWizard from "@/components/request/RequestWizard";

export const metadata: Metadata = { title: "Design request" };

export default function RequestPage() {
  return (
    <>
      <header className="mx-auto flex max-w-2xl items-center justify-between px-4 pt-4">
        <Link href="/" aria-label="Ultrapro home"><Logo height={32} /></Link>
      </header>
      <RequestWizard />
    </>
  );
}
