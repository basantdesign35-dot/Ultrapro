import Link from "next/link";
import Logo from "@/components/Logo";

export default function Home() {
  return (
    <main className="mx-auto flex min-h-screen max-w-3xl flex-col px-5 py-6">
      <header className="flex items-center justify-between">
        <Logo />
        <Link href="/designer/login" className="text-sm text-slate-600 underline-offset-4 hover:underline">Designer login</Link>
      </header>

      <section className="flex flex-1 flex-col justify-center py-12">
        <h1 className="text-4xl font-bold leading-tight sm:text-5xl">Let&apos;s Design Your Paper Bag</h1>
        <p className="mt-4 max-w-xl text-lg text-slate-700">
          Share your brand details and design preferences. Our team will take care of the rest.
        </p>
        <div className="mt-8">
          <Link href="/request" className="btn btn-primary text-lg">Start Design Request</Link>
        </div>
        <ul className="mt-10 max-w-xl space-y-3 text-slate-700">
          <li>Tell us about your brand and the bag size. If you don&apos;t know the size, that&apos;s fine.</li>
          <li>Choose what goes on the front, back, left and right of the bag.</li>
          <li>Type your instructions in Hindi, English or Hinglish, or record them with your voice.</li>
        </ul>
        <p className="mt-6 text-sm text-slate-500">It takes about 2–3 minutes when your details are ready.</p>
      </section>

      <footer className="border-t border-line pt-4 text-xs text-slate-500">
        Your details are used only to prepare your design and to contact you about it.
      </footer>
    </main>
  );
}
