import type { Metadata } from "next";
import AuthProvider from "@/components/designer/AuthProvider";

export const metadata: Metadata = { robots: { index: false, follow: false } };

export default function DesignerLayout({ children }: { children: React.ReactNode }) {
  return <AuthProvider>{children}</AuthProvider>;
}
