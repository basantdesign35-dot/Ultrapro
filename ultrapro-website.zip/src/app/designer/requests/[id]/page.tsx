"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { onValue, ref } from "firebase/database";
import DesignerShell from "@/components/designer/DesignerShell";
import Workspace from "@/components/designer/Workspace";
import { useAuth } from "@/components/designer/AuthProvider";
import { db } from "@/lib/firebase";
import { PANEL_KEYS } from "@/lib/panels";
import { bagSizeText, panelBrief, pendingItems } from "@/lib/brief";
import { telUrl, whatsappUrl } from "@/lib/phone";
import { buildBriefPdf, pdfCanRender } from "@/lib/pdf";
import { download } from "@/lib/download";
import type { RequestRecord } from "@/lib/record";

const ORIGIN = {
  client: { label: "Client-provided", cls: "bg-brand-50 text-brand-700" },
  designer: { label: "Designer's choice", cls: "bg-violet-50 text-violet-800" },
  pending: { label: "Pending confirmation", cls: "bg-amber-50 text-amber-800" },
  blank: { label: "Blank", cls: "bg-slate-100 text-slate-700" },
} as const;

const Row = ({ label, value }: { label: string; value?: string | null }) => (
  <div className="grid gap-0.5 py-1.5 sm:grid-cols-3"><dt className="text-sm text-slate-500">{label}</dt><dd className="whitespace-pre-wrap sm:col-span-2">{value || "—"}</dd></div>
);

function Detail() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const { profile } = useAuth();
  const [rec, setRec] = useState<RequestRecord | null | undefined>(undefined);
  const [error, setError] = useState<string | null>(null);
  const [pdfMsg, setPdfMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!/^[A-Z0-9-]{6,40}$/.test(id)) { setRec(null); return; }
    return onValue(ref(db(), `designRequests/${id}`), (s) => { setRec(s.exists() ? (s.val() as RequestRecord) : null); setError(null); },
      () => setError("You do not have permission to view this request."));
  }, [id]);

  if (error) return <p role="alert" className="text-red-700">{error}</p>;
  if (rec === undefined) return <p className="text-slate-600">Loading request…</p>;
  if (rec === null) return <div><p>This request was not found.</p><Link href="/designer" className="text-brand-600 underline">Back to requests</Link></div>;

  const wa = whatsappUrl(rec.contactPhoneDigits);
  const tel = telUrl(rec.contactPhoneDigits);
  const pend = pendingItems(rec);

  const makePdf = () => {
    const { blob, name, replacedChars } = buildBriefPdf(rec);
    download(blob, name);
    setPdfMsg(replacedChars || !pdfCanRender(rec) ? "Some characters (for example Hindi) cannot be drawn in this PDF and were replaced with “?”. Use “Print / Save as PDF” to get every character." : null);
  };

  return (
    <article className="space-y-6">
      <div className="no-print"><Link href="/designer" className="text-sm text-brand-600 underline">← All requests</Link></div>
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">{rec.brandName}</h1>
          <p className="text-sm tabular-nums text-slate-500">{rec.requestId} · submitted {rec.createdAt ? new Date(rec.createdAt).toLocaleString("en-IN") : "—"}</p>
        </div>
        <div className="no-print flex flex-wrap gap-2">
          <button className="btn btn-primary min-h-[44px] px-4 text-sm" onClick={makePdf}>Download brief (PDF)</button>
          <button className="btn btn-secondary min-h-[44px] px-4 text-sm" onClick={() => window.print()}>Print / Save as PDF</button>
        </div>
      </header>
      {pdfMsg && <p role="status" className="no-print rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm">{pdfMsg}</p>}

      <section className="card" aria-labelledby="a">
        <h2 id="a" className="mb-1 font-semibold">A. Client information</h2>
        <dl className="divide-y divide-line">
          <Row label="Contact person" value={rec.contactName} /><Row label="Brand" value={rec.brandName} />
          <Row label="WhatsApp / phone" value={rec.contactPhone} /><Row label="Alternate number" value={rec.alternatePhone} />
          <Row label="Prefers" value={rec.preferredContact === "whatsapp" ? "WhatsApp" : rec.preferredContact === "call" ? "Phone call" : "WhatsApp and call"} />
          <Row label="Number to print" value={rec.clientDetails.printPhone ? `${rec.clientDetails.printPhone}${rec.clientDetails.useContactNumberOnBag ? " (same as contact number)" : ""}` : "Not printing a phone number"} />
          <Row label="Address" value={rec.clientDetails.shopAddress} /><Row label="Tagline" value={rec.clientDetails.tagline} />
          <Row label="Email" value={rec.clientDetails.email} /><Row label="Instagram / website" value={rec.clientDetails.social} />
          <Row label="Client wants printed" value={Object.entries(rec.clientDetails.printOnBag).filter(([, v]) => v).map(([k]) => k).join(", ")} />
        </dl>
        <div className="no-print mt-3 flex gap-2">
          {tel && <a className="btn btn-secondary min-h-[44px] px-4 text-sm" href={tel}>Call</a>}
          {wa && <a className="btn btn-secondary min-h-[44px] px-4 text-sm" href={wa} target="_blank" rel="noopener noreferrer">WhatsApp</a>}
        </div>
      </section>

      <section className="card" aria-labelledby="b">
        <h2 id="b" className="mb-1 font-semibold">B. Bag specifications</h2>
        <dl className="divide-y divide-line">
          <Row label="Size (W × H × D)" value={bagSizeText(rec)} />
          <Row label="Size status" value={rec.bagSpecifications.sizeStatus === "pending_confirmation" ? "Pending confirmation" : "Provided by client"} />
          <Row label="Background colour" value={rec.bagSpecifications.backgroundColor} /><Row label="Printing colours" value={rec.bagSpecifications.printColors} />
          <Row label="Size / printing notes" value={rec.bagSpecifications.extraInstructions} />
        </dl>
      </section>

      <section aria-labelledby="c" className="space-y-3">
        <h2 id="c" className="font-semibold">C. Panel-wise design brief</h2>
        <div className="grid gap-3 md:grid-cols-2">
          {PANEL_KEYS.map((k) => {
            const b = panelBrief(rec, k);
            const o = ORIGIN[b.origin];
            return (
              <div key={k} className="card space-y-2 break-inside-avoid">
                <div className="flex items-center justify-between gap-2"><h3 className="text-lg font-bold">{b.title}</h3><span className={`rounded-full px-2.5 py-1 text-xs font-medium ${o.cls}`}>{o.label}</span></div>
                <p className="text-sm font-medium">{b.modeLabel}</p>
                <p className="text-sm">{b.headline}</p>
                {b.lines.length > 0 && <dl className="divide-y divide-line text-sm">{b.lines.map((l) => <Row key={l.label} label={l.label} value={l.value} />)}</dl>}
                {b.note && <p className="text-xs text-amber-800">{b.note}</p>}
              </div>
            );
          })}
        </div>
      </section>

      <section className="card" aria-labelledby="d">
        <h2 id="d" className="mb-1 font-semibold">D. Additional instructions</h2>
        <dl className="divide-y divide-line">
          <Row label="Written notes" value={rec.writtenInstructions} />
          <Row label="Designer decides layout" value={rec.designerDecidesLayout ? "Yes" : "No"} />
          <Row label="Voice recording" value={rec.audio.recordedByClient ? `Client recorded ${rec.audio.seconds}s. Not stored in this system.` : "None"} />
          <Row label="Files selected by client" value={rec.assetMetadata.length ? rec.assetMetadata.map((a) => `${a.label}: ${a.fileName} (not uploaded)`).join("\n") : "None"} />
        </dl>
      </section>

      <section className="card border-amber-300 bg-amber-50" aria-labelledby="p">
        <h2 id="p" className="mb-1 font-semibold">Missing or pending</h2>
        {pend.length ? <ul className="list-disc space-y-1 pl-5 text-sm">{pend.map((p) => <li key={p}>{p}</li>)}</ul> : <p className="text-sm">Nothing pending.</p>}
      </section>

      {profile && <Workspace rec={rec} />}
    </article>
  );
}
export default function RequestDetailPage() { return <DesignerShell><Detail /></DesignerShell>; }
