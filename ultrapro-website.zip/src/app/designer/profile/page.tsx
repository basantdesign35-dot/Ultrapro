"use client";
import { useRouter } from "next/navigation";
import DesignerShell from "@/components/designer/DesignerShell";
import { useAuth } from "@/components/designer/AuthProvider";

function Inner() {
  const { profile, user, logout } = useAuth();
  const router = useRouter();
  if (!profile || !user) return null;
  return (
    <div className="max-w-md space-y-4">
      <h1 className="text-2xl font-bold">Profile</h1>
      <dl className="card divide-y divide-line">
        <div className="py-2"><dt className="text-sm text-slate-600">Name</dt><dd>{profile.displayName}</dd></div>
        <div className="py-2"><dt className="text-sm text-slate-600">Email</dt><dd>{profile.email}</dd></div>
        <div className="py-2"><dt className="text-sm text-slate-600">Role</dt><dd className="capitalize">{profile.role}</dd></div>
      </dl>
      <p className="text-sm text-slate-600">Your name, role and active status can only be changed by an administrator.</p>
      <button className="btn btn-secondary" onClick={async () => { await logout(); router.replace("/designer/login"); }}>Sign out</button>
    </div>
  );
}
export default function ProfilePage() { return <DesignerShell><Inner /></DesignerShell>; }
