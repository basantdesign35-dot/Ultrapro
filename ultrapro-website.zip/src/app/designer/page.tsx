"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import DesignerShell from "@/components/designer/DesignerShell";
import { useAuth } from "@/components/designer/AuthProvider";
import { useDirectory, useRequests } from "@/components/designer/useRequests";
import { bagSizeText } from "@/lib/brief";
import { telUrl, whatsappUrl } from "@/lib/phone";

const STATUS = { new: "New", in_progress: "In Progress", completed: "Completed" } as const;
const BADGE = { new: "bg-brand-50 text-brand-700", in_progress: "bg-amber-50 text-amber-800", completed: "bg-green-50 text-green-800" } as const;

function Dashboard() {
  const { user } = useAuth();
  const { items, error } = useRequests();
  const dir = useDirectory();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<"all" | keyof typeof STATUS>("all");
  const [mine, setMine] = useState(false);

  const shown = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return (items ?? []).filter((r) => {
      if (status !== "all" && r.status !== status) return false;
      if (mine && r.assignedDesignerUid !== user?.uid) return false;
      if (!needle) return true;
      return [r.requestId, r.brandName, r.contactName, r.contactPhone, r.contactPhoneDigits].some((f) => (f ?? "").toLowerCase().includes(needle));
    });
  }, [items, q, status, mine, user]);

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold">Design Requests</h1>
      <div className="flex flex-col gap-3 sm:flex-row">
        <input className="input sm:max-w-xs" type="search" placeholder="Search brand, name, phone, ID" aria-label="Search requests" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input sm:max-w-[200px]" aria-label="Filter by status" value={status} onChange={(e) => setStatus(e.target.value as typeof status)}>
          <option value="all">All statuses</option>
          {Object.entries(STATUS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
        </select>
        <label className="flex min-h-[48px] items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5 accent-[#1f6fd1]" checked={mine} onChange={(e) => setMine(e.target.checked)} />Assigned to me</label>
      </div>

      {error && <p role="alert" className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800">{error}</p>}
      {!error && items === null && <p className="text-slate-600">Loading requests…</p>}
      {!error && items && shown.length === 0 && <p className="card text-slate-600">{items.length === 0 ? "No requests yet. New client requests will appear here." : "No requests match your filters."}</p>}

      <ul className="grid gap-3 md:grid-cols-2">
        {shown.map((r) => {
          const wa = whatsappUrl(r.contactPhoneDigits);
          const tel = telUrl(r.contactPhoneDigits);
          return (
            <li key={r.requestId} className="card space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <Link href={`/designer/requests/${r.requestId}`} className="text-lg font-semibold hover:underline">{r.brandName}</Link>
                  <p className="text-xs tabular-nums text-slate-500">{r.requestId}</p>
                </div>
                <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${BADGE[r.status] ?? ""}`}>{STATUS[r.status] ?? r.status}</span>
              </div>
              <dl className="grid grid-cols-2 gap-x-3 gap-y-1 text-sm">
                <dt className="text-slate-500">Contact</dt><dd>{r.contactName}</dd>
                <dt className="text-slate-500">Phone</dt><dd>{r.contactPhone}</dd>
                <dt className="text-slate-500">Bag size</dt><dd>{bagSizeText(r)}</dd>
                <dt className="text-slate-500">Submitted</dt><dd>{r.createdAt ? new Date(r.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "—"}</dd>
                <dt className="text-slate-500">Designer</dt><dd>{r.assignedDesignerUid ? dir[r.assignedDesignerUid]?.displayName ?? "Assigned" : "Unassigned"}</dd>
              </dl>
              {r.delivery?.formspree === "failed" && <p className="text-xs text-amber-800">Email copy was not delivered (record is saved).</p>}
              <div className="flex flex-wrap gap-2">
                {tel && <a className="btn btn-secondary min-h-[44px] px-4 text-sm" href={tel}>Call</a>}
                {wa && <a className="btn btn-secondary min-h-[44px] px-4 text-sm" href={wa} target="_blank" rel="noopener noreferrer">WhatsApp</a>}
                <Link className="btn btn-primary min-h-[44px] px-4 text-sm" href={`/designer/requests/${r.requestId}`}>Open</Link>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
export default function DashboardPage() { return <DesignerShell><Dashboard /></DesignerShell>; }
