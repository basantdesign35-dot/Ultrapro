"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Logo from "@/components/Logo";
import { useAuth } from "@/components/designer/AuthProvider";

export default function LoginPage() {
  const { user, loading, signIn, resetPassword, configured } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  useEffect(() => { if (!loading && user) router.replace("/designer"); }, [loading, user, router]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null); setInfo(null);
    if (!/^\S+@\S+\.\S+$/.test(email)) return setError("Enter a valid email address.");
    if (password.length < 6) return setError("Enter your password.");
    setBusy(true);
    const err = await signIn(email, password, remember);
    setBusy(false);
    if (err) setError(err); else router.replace("/designer");
  };

  const reset = async () => {
    setError(null); setInfo(null);
    if (!/^\S+@\S+\.\S+$/.test(email)) return setError("Enter your email above first.");
    const err = await resetPassword(email);
    if (err) setError(err); else setInfo("If this email belongs to a designer account, a reset link has been sent.");
  };

  return (
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center px-5">
      <Logo />
      <h1 className="mt-8 text-2xl font-bold">Designer login</h1>
      {!configured && <p role="alert" className="mt-3 rounded-lg bg-amber-50 p-3 text-sm">Firebase is not configured yet. See the setup guide.</p>}
      <form onSubmit={submit} className="mt-5 space-y-4" noValidate>
        <div><label htmlFor="email" className="mb-1 block text-sm font-medium">Email</label>
          <input id="email" type="email" autoComplete="username" className="input" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div><label htmlFor="pw" className="mb-1 block text-sm font-medium">Password</label>
          <input id="pw" type="password" autoComplete="current-password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
        <label className="flex min-h-[44px] items-center gap-3 text-sm"><input type="checkbox" className="h-5 w-5 accent-[#1f6fd1]" checked={remember} onChange={(e) => setRemember(e.target.checked)} />Keep me signed in on this device</label>
        {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
        {info && <p role="status" className="text-sm text-green-700">{info}</p>}
        <button className="btn btn-primary w-full" disabled={busy || !configured}>{busy ? "Signing in…" : "Sign in"}</button>
        <button type="button" onClick={reset} className="w-full text-sm text-brand-600 underline">Forgot password?</button>
      </form>
      <p className="mt-8 text-xs text-slate-500">Accounts are created by an Ultrapro administrator. There is no public sign-up.</p>
    </main>
  );
}
