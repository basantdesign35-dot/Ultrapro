"use client";
import { useId, useState } from "react";
import { attachments, validateClientFile } from "@/lib/attachments";
import { useAttachments } from "@/lib/useAttachments";

export default function FileInput({ storeKey, label, hint }: { storeKey: string; label: string; hint?: string }) {
  const id = useId();
  const all = useAttachments();
  const current = all.find((a) => a.key === storeKey);
  const [error, setError] = useState<string | null>(null);

  return (
    <div className="space-y-1">
      <label htmlFor={id} className="block text-sm font-medium">{label}</label>
      {hint && <p className="text-xs text-slate-600">{hint}</p>}
      {current ? (
        <div className="flex items-center justify-between gap-2 rounded-lg border border-line p-3 text-sm">
          <span className="truncate">{current.fileName} · {(current.blob.size / 1024).toFixed(0)} KB · kept on this device</span>
          <button type="button" className="min-h-[40px] shrink-0 rounded-lg border border-line px-3" onClick={() => attachments.remove(storeKey)}>Remove</button>
        </div>
      ) : (
        <input
          id={id}
          type="file"
          accept="image/png,image/jpeg,image/webp,application/pdf"
          className="block w-full min-h-[48px] rounded-lg border border-line p-2 text-sm file:mr-3 file:min-h-[36px] file:rounded-md file:border-0 file:bg-brand-50 file:px-3 file:text-brand-700"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            const err = validateClientFile(f);
            if (err) { setError(err); e.target.value = ""; return; }
            setError(null);
            attachments.set({ key: storeKey, label, blob: f, fileName: f.name, kind: "file" });
          }}
        />
      )}
      {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
    </div>
  );
}
