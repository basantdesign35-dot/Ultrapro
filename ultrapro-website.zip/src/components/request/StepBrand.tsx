"use client";
import { Controller, useFormContext } from "react-hook-form";
import type { FormInput } from "@/lib/schema";
import { Check, Field } from "@/components/ui";
import FileInput from "@/components/FileInput";

export default function StepBrand() {
  const { register, control, watch, formState: { errors } } = useFormContext<FormInput>();
  const useContact = watch("brand.useContactOnBag");
  const e = errors.brand;

  return (
    <div className="space-y-5">
      <Field label="Shop / Brand name" required error={e?.brandName?.message} htmlFor="brandName">
        <input id="brandName" className="input" autoComplete="organization" aria-invalid={!!e?.brandName} {...register("brand.brandName")} />
      </Field>
      <Field label="Contact person name" required error={e?.contactName?.message} htmlFor="contactName">
        <input id="contactName" className="input" autoComplete="name" aria-invalid={!!e?.contactName} {...register("brand.contactName")} />
      </Field>
      <Field label="Contact phone / WhatsApp number" required error={e?.contactPhone?.message} htmlFor="contactPhone" hint="We use this to talk to you about your design.">
        <input id="contactPhone" className="input" inputMode="tel" autoComplete="tel" placeholder="98765 43210" aria-invalid={!!e?.contactPhone} {...register("brand.contactPhone")} />
      </Field>
      <Field label="Alternate contact number" error={e?.alternatePhone?.message} htmlFor="alt">
        <input id="alt" className="input" inputMode="tel" aria-invalid={!!e?.alternatePhone} {...register("brand.alternatePhone")} />
      </Field>

      <fieldset>
        <legend className="mb-1 text-sm font-medium">How should we contact you?</legend>
        <div className="grid grid-cols-3 gap-2">
          {([["whatsapp", "WhatsApp"], ["call", "Phone call"], ["both", "Both"]] as const).map(([v, l]) => (
            <label key={v} className="flex min-h-[48px] cursor-pointer items-center justify-center rounded-lg border border-line px-2 text-center text-sm has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50 has-[:checked]:font-semibold">
              <input type="radio" value={v} className="sr-only" {...register("brand.preferredContact")} />
              {l}
            </label>
          ))}
        </div>
      </fieldset>

      <div className="card space-y-3">
        <h2 className="font-semibold">What should be printed on the bag?</h2>
        <p className="text-sm text-slate-600">The number we call may be different from the number printed on the bag.</p>
        <Controller control={control} name="brand.useContactOnBag" render={({ field }) => (
          <Check id="useContact" label="Use my contact number on the bag" checked={!!field.value} onChange={(ev) => field.onChange(ev.target.checked)} />
        )} />
        {!useContact && (
          <Field label="Phone number to print on the bag" required error={e?.printPhone?.message} htmlFor="printPhone">
            <input id="printPhone" className="input" inputMode="tel" aria-invalid={!!e?.printPhone} {...register("brand.printPhone")} />
          </Field>
        )}
        <div className="grid grid-cols-2 gap-x-3">
          {([["logo", "Logo"], ["phone", "Phone number"], ["address", "Shop address"], ["tagline", "Tagline"], ["email", "Email"], ["social", "Instagram / website"]] as const).map(([k, l]) => (
            <Controller key={k} control={control} name={`brand.printOn.${k}`} render={({ field }) => (
              <Check id={`print-${k}`} label={l} checked={!!field.value} onChange={(ev) => field.onChange(ev.target.checked)} />
            )} />
          ))}
        </div>
      </div>

      <Field label="Shop address" htmlFor="addr"><textarea id="addr" rows={2} className="input" autoComplete="street-address" {...register("brand.shopAddress")} /></Field>
      <Field label="Tagline" htmlFor="tag"><input id="tag" className="input" {...register("brand.tagline")} /></Field>
      <Field label="Email" error={e?.email?.message} htmlFor="email"><input id="email" type="email" className="input" autoComplete="email" {...register("brand.email")} /></Field>
      <Field label="Instagram / website" htmlFor="social"><input id="social" className="input" {...register("brand.social")} /></Field>

      <div className="card space-y-4">
        <h2 className="font-semibold">Logo and reference photo</h2>
        <FileInput storeKey="brand-logo" label="Brand logo" hint="PNG, JPG, WEBP or PDF, up to 10 MB." />
        <FileInput storeKey="visiting-card" label="Visiting card / reference photo" />
        <p className="rounded-lg bg-slate-50 p-3 text-xs text-slate-700">
          Files stay on your device. This form cannot upload them. After you submit, you can download a package and send it to your designer on WhatsApp.
        </p>
      </div>
    </div>
  );
}
