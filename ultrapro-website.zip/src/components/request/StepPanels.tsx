"use client";
import { useFormContext, useWatch } from "react-hook-form";
import { Field } from "@/components/ui";
import FileInput from "@/components/FileInput";
import AudioRecorder from "@/components/AudioRecorder";
import { PANEL_KEYS, PANEL_LABEL, MODE_LABEL, isReference, resolveSource, validSources, type PanelKey, type PanelMode } from "@/lib/panels";
import { hasPanelContent, type FormInput, type FormValues } from "@/lib/schema";

const MODES: PanelMode[] = ["custom", "repeat", "designer", "blank", "same_diff_layout"];

export default function StepPanels() {
  const { register, setValue, getValues, formState: { errors } } = useFormContext<FormInput>();
  const panels = useWatch<FormInput, "panels">({ name: "panels" }) as FormInput["panels"];

  const letDesignerDecide = () => {
    PANEL_KEYS.forEach((k) => {
      const p = getValues(`panels.${k}`) as FormValues["panels"][PanelKey];
      if (p.mode === "custom") {
        if (hasPanelContent(p)) setValue(`panels.${k}.layoutByDesigner`, true, { shouldDirty: true });
        else setValue(`panels.${k}.mode`, "designer", { shouldDirty: true });
      }
    });
    setValue("instructions.designerDecidesLayout", true, { shouldDirty: true });
  };

  const chooseMode = (k: PanelKey, mode: PanelMode) => {
    setValue(`panels.${k}.mode`, mode, { shouldDirty: true, shouldValidate: true });
    if (isReference(mode)) {
      const trial = { ...panels, [k]: { ...panels[k], mode } } as never;
      const options = validSources(trial, k);
      const current = panels[k].sourcePanel as PanelKey | "";
      if (!current || !options.includes(current as PanelKey)) setValue(`panels.${k}.sourcePanel`, options[0] ?? "", { shouldDirty: true, shouldValidate: true });
    }
  };

  return (
    <div className="space-y-5">
      <div className="card flex flex-col gap-3 bg-brand-50 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm">Not sure about the layout? Our designer can decide it. Your phone number, address and exact text stay as you entered them.</p>
        <button type="button" onClick={letDesignerDecide} className="btn btn-secondary shrink-0">Let the Designer Decide</button>
      </div>

      {PANEL_KEYS.map((k) => {
        const p = panels[k];
        const err = (errors.panels?.[k]?.sourcePanel as { message?: string } | undefined)?.message;
        const options = validSources(panels as never, k);
        const resolved = isReference(p.mode) ? resolveSource(panels as never, k) : null;
        return (
          <section key={k} className="card space-y-4" aria-labelledby={`panel-${k}`}>
            <h2 id={`panel-${k}`} className="text-lg font-bold">{PANEL_LABEL[k].toUpperCase()}</h2>

            <fieldset>
              <legend className="sr-only">What goes on the {PANEL_LABEL[k]} panel</legend>
              <div className="flex flex-wrap gap-2">
                {MODES.map((m) => (
                  <label key={m} className={`flex min-h-[44px] cursor-pointer items-center rounded-lg border px-3 text-sm ${p.mode === m ? "border-brand-600 bg-brand-50 font-semibold" : "border-line"}`}>
                    <input type="radio" className="sr-only" checked={p.mode === m} onChange={() => chooseMode(k, m)} name={`mode-${k}`} />
                    {MODE_LABEL[m]}
                  </label>
                ))}
              </div>
            </fieldset>

            {isReference(p.mode) && (
              <div className="space-y-2">
                <Field label={p.mode === "repeat" ? "Repeat which panel?" : "Use the content of which panel?"} required htmlFor={`src-${k}`} error={err}>
                  <select id={`src-${k}`} className="input" value={p.sourcePanel ?? ""} onChange={(e) => setValue(`panels.${k}.sourcePanel`, e.target.value as PanelKey, { shouldDirty: true, shouldValidate: true })}>
                    <option value="" disabled>Choose a panel</option>
                    {options.map((o) => <option key={o} value={o}>{PANEL_LABEL[o]}</option>)}
                  </select>
                </Field>
                {resolved && (
                  <p className="rounded-lg bg-slate-50 p-3 text-sm">
                    {p.mode === "repeat" ? "This panel will be a copy of" : "Same content as"} <strong>{PANEL_LABEL[resolved].toUpperCase()}</strong>
                    {p.mode === "same_diff_layout" ? ", with a different layout." : "."}
                  </p>
                )}
                {p.mode === "same_diff_layout" && (
                  <Field label="Layout wishes" htmlFor={`lay-${k}`}><textarea id={`lay-${k}`} rows={2} className="input" {...register(`panels.${k}.notes`)} /></Field>
                )}
              </div>
            )}

            {p.mode === "designer" && (
              <p className="rounded-lg bg-brand-50 p-3 text-sm">Let our designer decide the layout and creative elements. Add any details that must appear exactly as written:</p>
            )}
            {p.mode === "blank" && <p className="rounded-lg bg-slate-50 p-3 text-sm">This panel will be left blank.</p>}

            {(p.mode === "custom" || p.mode === "designer") && (
              <div className="space-y-4">
                <Field label="Exact text to print" htmlFor={`txt-${k}`}><textarea id={`txt-${k}`} rows={2} className="input" {...register(`panels.${k}.exactText`)} /></Field>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Phone number" htmlFor={`ph-${k}`}><input id={`ph-${k}`} className="input" inputMode="tel" {...register(`panels.${k}.phone`)} /></Field>
                  <Field label="Social media" htmlFor={`so-${k}`}><input id={`so-${k}`} className="input" {...register(`panels.${k}.social`)} /></Field>
                </div>
                <Field label="Address" htmlFor={`ad-${k}`}><textarea id={`ad-${k}`} rows={2} className="input" {...register(`panels.${k}.address`)} /></Field>
                {p.mode === "custom" && (
                  <>
                    <Field label="QR code (what should it open?)" htmlFor={`qr-${k}`}><input id={`qr-${k}`} className="input" placeholder="e.g. Instagram page link" {...register(`panels.${k}.qr`)} /></Field>
                    <Field label="Logo placement" htmlFor={`lp-${k}`}><input id={`lp-${k}`} className="input" placeholder="e.g. big logo in the centre" {...register(`panels.${k}.logoPlacement`)} /></Field>
                    <Field label="Other instructions" htmlFor={`nt-${k}`}><textarea id={`nt-${k}`} rows={3} className="input" placeholder="Front par logo bada rakhna…" {...register(`panels.${k}.notes`)} /></Field>
                    <FileInput storeKey={`panel-${k}-ref`} label="Reference image for this panel" />
                    <details className="rounded-lg border border-line p-3">
                      <summary className="min-h-[40px] cursor-pointer text-sm font-medium">Add a voice note for this panel</summary>
                      <div className="mt-3"><AudioRecorder storeKey={`panel-${k}-voice`} label={`${PANEL_LABEL[k]} panel voice note`} onChange={() => undefined} /></div>
                    </details>
                  </>
                )}
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}
