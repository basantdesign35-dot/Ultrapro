"use client";
import { Controller, useFormContext } from "react-hook-form";
import type { FormInput } from "@/lib/schema";
import { Check, Field } from "@/components/ui";
import FileInput from "@/components/FileInput";

export default function StepBag() {
  const { register, control, watch, formState: { errors } } = useFormContext<FormInput>();
  const unknown = watch("bag.sizeUnknown");
  const unit = watch("bag.unit");
  const e = errors.bag;

  return (
    <div className="space-y-5">
      <Controller control={control} name="bag.sizeUnknown" render={({ field }) => (
        <Check id="unknownSize" label="I don't know my bag size" checked={!!field.value} onChange={(ev) => field.onChange(ev.target.checked)} />
      )} />
      {unknown ? (
        <p className="rounded-lg border border-line bg-slate-50 p-3 text-sm">Bag size will be marked <strong>Pending confirmation</strong>. Our team will check it with you.</p>
      ) : (
        <>
          <fieldset>
            <legend className="mb-1 text-sm font-medium">Measurement unit</legend>
            <div className="grid grid-cols-2 gap-2">
              {([["in", "Inches"], ["cm", "Centimeters"]] as const).map(([v, l]) => (
                <label key={v} className="flex min-h-[48px] cursor-pointer items-center justify-center rounded-lg border border-line has-[:checked]:border-brand-600 has-[:checked]:bg-brand-50 has-[:checked]:font-semibold">
                  <input type="radio" value={v} className="sr-only" {...register("bag.unit")} />
                  {l}
                </label>
              ))}
            </div>
          </fieldset>
          <div className="grid grid-cols-3 gap-3">
            {([["width", "Width"], ["height", "Height"], ["depth", "Depth / gusset"]] as const).map(([k, l]) => (
              <Field key={k} label={l} required htmlFor={k}>
                <input id={k} className="input" inputMode="decimal" placeholder={unit === "in" ? "in" : "cm"} aria-invalid={!!e?.[k]} {...register(`bag.${k}`)} />
              </Field>
            ))}
          </div>
          {(e?.width || e?.height || e?.depth) && (
            <p role="alert" className="text-sm text-red-700">Enter all three sizes as numbers greater than 0, or tick “I don&apos;t know my bag size”.</p>
          )}
        </>
      )}

      <Field label="Preferred bag background colour" htmlFor="bg"><input id="bg" className="input" placeholder="e.g. white, brown kraft, red" {...register("bag.backgroundColor")} /></Field>
      <Field label="Preferred printing colours" htmlFor="pc"><input id="pc" className="input" placeholder="e.g. black and gold" {...register("bag.printColors")} /></Field>
      <Field label="Additional size or printing instructions" htmlFor="extra"><textarea id="extra" rows={3} className="input" {...register("bag.extraInstructions")} /></Field>

      <div className="card space-y-4">
        <FileInput storeKey="existing-bag" label="Existing bag photo" />
        <FileInput storeKey="reference-design" label="Reference design" />
      </div>
    </div>
  );
}
