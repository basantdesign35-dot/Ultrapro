"use client";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import Logo from "@/components/Logo";
import { attachments } from "@/lib/attachments";
import { useAttachments } from "@/lib/useAttachments";
import { buildRequestPackage, download } from "@/lib/package";
import type { RequestRecord } from "@/lib/record";
import { SUB_KEY } from "./RequestWizard";

export default function SuccessView() {
  const id = useSearchParams().get("id") ?? "";
  const files = useAttachments();
  const [rec, setRec] = useState<RequestRecord | null>(null);
  const [valid, setValid] = useState<boolean | null>(null);

  useEffect(() => {
    try {
      const s = JSON.parse(sessionStorage.getItem(SUB_KEY) ?? "null");
      // only show a confirmation that matches a request this browser actually completed
      const ok = !!s && s.requestId === id && s.formspree === "delivered";
      setValid(ok);
      if (ok) setRec(s.rec);
    } catch { setValid(false); }
  }, [id]);

  const wa = (process.env.NEXT_PUBLIC_COMPANY_WHATSAPP ?? "").replace(/\D/g, "");
  const waUrl = /^\d{8,15}$/.test(wa) ? `https://wa.me/${wa}?text=${encodeURIComponent(`Hello Ultrapro, my design request ID is ${id}. I am sending my files.`)}` : null;

  if (valid === null) return <p className="p-6">Loading…</p>;
  if (!valid) {
    return (
      <main className="mx-auto max-w-xl p-6">
        <h1 className="text-2xl font-bold">No confirmed request found</h1>
        <p className="mt-2 text-slate-700">We can only show a confirmation right after a request is submitted from this browser.</p>
        <Link href="/request" className="btn btn-primary mt-5">Start Design Request</Link>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-xl px-5 py-8">
      <Logo height={32} />
      <h1 className="mt-8 text-3xl font-bold">Request received</h1>
      <p className="mt-2 text-slate-700">Your request ID is <strong className="tabular-nums">{id}</strong>. Please keep it. Our team will contact you.</p>

      {files.length > 0 && rec && (
        <section className="card mt-6 space-y-3 border-amber-300 bg-amber-50">
          <h2 className="font-semibold">One more step: send your files</h2>
          <p className="text-sm">You selected {files.length} file or recording. They were <strong>not uploaded</strong>. Download the package and send it to your designer.</p>
          <div className="flex flex-wrap gap-2">
            <button className="btn btn-primary" onClick={async () => { const { blob, name } = await buildRequestPackage(rec, attachments.getSnapshot()); download(blob, name); }}>Download package</button>
            {waUrl && <a className="btn btn-secondary" href={waUrl} target="_blank" rel="noopener noreferrer">Open WhatsApp</a>}
          </div>
          <p className="text-xs text-slate-600">This page keeps your files only until you close or refresh it.</p>
        </section>
      )}

      <Link href="/" className="btn btn-secondary mt-8">Back to home</Link>
    </main>
  );
}
