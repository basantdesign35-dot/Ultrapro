"use client";
import { Controller, useFormContext } from "react-hook-form";
import { Check } from "@/components/ui";
import { PANEL_KEYS } from "@/lib/panels";
import { bagSizeText, pendingItems, panelBrief } from "@/lib/brief";
import { formSchema, type FormInput } from "@/lib/schema";
import { toRecord, type RequestRecord } from "@/lib/record";
import { useAttachments } from "@/lib/useAttachments";

export default function StepReview({ goTo }: { goTo: (step: number) => void }) {
  const { control, getValues, formState: { errors } } = useFormContext<FormInput>();
  const files = useAttachments();
  const raw = getValues();
  const parsed = formSchema.safeParse({ ...raw, consent: true });
  const stepFor = (path: string) => (path.startsWith("brand") ? 1 : path.startsWith("bag") ? 2 : path.startsWith("panels") ? 3 : 4);

  if (!parsed.success) {
    const steps = Array.from(new Set(parsed.error.issues.map((i) => stepFor(i.path.join(".")))));
    return (
      <div role="alert" className="card space-y-3 border-amber-300 bg-amber-50">
        <p className="font-semibold">A few details need fixing before you can submit.</p>
        <ul className="list-disc space-y-1 pl-5 text-sm">
          {parsed.error.issues.slice(0, 8).map((i, n) => <li key={n}>{i.message}</li>)}
        </ul>
        <div className="flex flex-wrap gap-2">
          {steps.map((s) => <button key={s} type="button" className="btn btn-secondary" onClick={() => goTo(s)}>Go to step {s}</button>)}
        </div>
      </div>
    );
  }

  const rec: RequestRecord = { ...toRecord(parsed.data, "(assigned on submit)"), status: "new" };
  const warnings = pendingItems(rec, "client");
  const hasVoice = files.some((f) => f.key === "global-voice");
  const others = files.filter((f) => f.key !== "global-voice");

  const Row = ({ label, value }: { label: string; value: string }) => (
    <div className="grid gap-0.5 py-1 sm:grid-cols-3"><dt className="text-sm text-slate-600">{label}</dt><dd className="sm:col-span-2">{value || "—"}</dd></div>
  );

  return (
    <div className="space-y-5">
      {warnings.length > 0 && (
        <div className="card border-amber-300 bg-amber-50 text-sm" role="status">
          <p className="mb-1 font-semibold">You can still submit, but note:</p>
          <ul className="list-disc space-y-1 pl-5">{warnings.map((w) => <li key={w}>{w}</li>)}</ul>
        </div>
      )}

      <section className="card">
        <div className="flex items-center justify-between"><h2 className="font-semibold">Brand and contact</h2><button type="button" className="text-sm text-brand-600 underline" onClick={() => goTo(1)}>Edit</button></div>
        <dl className="mt-2 divide-y divide-line">
          <Row label="Brand" value={rec.brandName} /><Row label="Contact person" value={rec.contactName} /><Row label="Contact number" value={rec.contactPhone} />
          <Row label="Number on bag" value={rec.clientDetails.printPhone || "Not printing a phone number"} />
        </dl>
      </section>

      <section className="card">
        <div className="flex items-center justify-between"><h2 className="font-semibold">Bag</h2><button type="button" className="text-sm text-brand-600 underline" onClick={() => goTo(2)}>Edit</button></div>
        <dl className="mt-2 divide-y divide-line">
          <Row label="Size" value={bagSizeText(rec)} /><Row label="Background colour" value={rec.bagSpecifications.backgroundColor} /><Row label="Printing colours" value={rec.bagSpecifications.printColors} />
        </dl>
      </section>

      <section className="card">
        <div className="flex items-center justify-between"><h2 className="font-semibold">Panels</h2><button type="button" className="text-sm text-brand-600 underline" onClick={() => goTo(3)}>Edit</button></div>
        <dl className="mt-2 divide-y divide-line">
          {PANEL_KEYS.map((k) => {
            const b = panelBrief(rec, k);
            return <Row key={k} label={b.title} value={[b.modeLabel + ": " + b.headline, ...b.lines.map((l) => `${l.label}: ${l.value}`)].join("\n")} />;
          })}
        </dl>
      </section>

      <section className="card">
        <div className="flex items-center justify-between"><h2 className="font-semibold">Instructions</h2><button type="button" className="text-sm text-brand-600 underline" onClick={() => goTo(4)}>Edit</button></div>
        <dl className="mt-2 divide-y divide-line">
          <Row label="Written" value={rec.writtenInstructions} />
          <Row label="Voice recording" value={hasVoice ? `Recorded (${rec.audio.seconds}s), on this device` : "None"} />
          <Row label="Files selected" value={others.length ? others.map((f) => f.fileName).join(", ") : "None"} />
        </dl>
        {(hasVoice || others.length > 0) && (
          <p className="mt-3 rounded-lg bg-slate-50 p-3 text-sm">Your recording and files are <strong>not uploaded</strong> by this form. After submitting you will get a package to send to your designer on WhatsApp.</p>
        )}
      </section>

      <div className="card space-y-2">
        <Controller control={control} name="consent" render={({ field }) => (
          <Check id="consent" label="I agree that Ultrapro may use these details to prepare my design and contact me about it." checked={!!field.value} onChange={(e) => field.onChange(e.target.checked)} />
        )} />
        {errors.consent && <p role="alert" className="text-sm text-red-700">{errors.consent.message}</p>}
        <p className="text-xs text-slate-500">Your details are shared only with Ultrapro&apos;s design team.</p>
      </div>
    </div>
  );
}
