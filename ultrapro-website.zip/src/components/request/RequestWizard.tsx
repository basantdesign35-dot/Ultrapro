"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { formSchema, STEP_FIELDS, type FormInput, type FormValues } from "@/lib/schema";
import { attachments } from "@/lib/attachments";
import { toRecord, type RequestRecord } from "@/lib/record";
import { sendToFormspree } from "@/lib/formspree";
import { buildRequestPackage, download } from "@/lib/package";
import { submissionText } from "@/lib/brief";
import StepBrand from "./StepBrand";
import StepBag from "./StepBag";
import StepPanels from "./StepPanels";
import StepInstructions from "./StepInstructions";
import StepReview from "./StepReview";

const DRAFT_KEY = "ultrapro:draft:v1";
export const SUB_KEY = "ultrapro:submission:v1";
const TITLES = ["Brand and contact", "Bag details", "Bag panels", "Instructions", "Review and send"];

interface Sub { requestId: string; clientKey: string; formspree: "pending" | "delivered" | "failed"; rec: RequestRecord }

const newKey = () =>
  typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : Array.from({ length: 4 }, () => Math.random().toString(16).slice(2, 10)).join("");

const defaults = (): FormInput => ({
  brand: {
    brandName: "", contactName: "", contactPhone: "", alternatePhone: "", preferredContact: "whatsapp",
    shopAddress: "", tagline: "", email: "", social: "", useContactOnBag: true, printPhone: "",
    printOn: { logo: true, phone: true, address: false, tagline: false, email: false, social: false },
  },
  bag: { sizeUnknown: false, width: "", height: "", depth: "", unit: "in", backgroundColor: "", printColors: "", extraInstructions: "" },
  panels: {
    front: { mode: "custom", sourcePanel: "" },
    back: { mode: "repeat", sourcePanel: "front" },
    left: { mode: "designer", sourcePanel: "" },
    right: { mode: "repeat", sourcePanel: "left" },
  } as FormInput["panels"],
  instructions: { written: "", designerDecidesLayout: false, hasAudio: false, audioSeconds: 0, audioMime: "" },
  assets: [],
  consent: false as unknown as true,
  website: "",
  clientKey: "",
  startedAt: 0,
});

const loadSub = (): Sub | null => { try { const s = sessionStorage.getItem(SUB_KEY); return s ? (JSON.parse(s) as Sub) : null; } catch { return null; } };
const saveSub = (s: Sub) => { try { sessionStorage.setItem(SUB_KEY, JSON.stringify(s)); } catch { /* private mode */ } };

export default function RequestWizard() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState<null | "saving" | "sending">(null);
  const [error, setError] = useState<string | null>(null);
  const [partial, setPartial] = useState<Sub | null>(null);
  const lock = useRef(false);

  const methods = useForm<FormInput, unknown, FormValues>({ resolver: zodResolver(formSchema) as never, defaultValues: defaults(), mode: "onTouched" });
  const { trigger, getValues, setValue, watch, reset } = methods;

  // restore draft (text only; files and recordings never survive a reload)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(DRAFT_KEY);
      if (raw) {
        const d = JSON.parse(raw) as { values: FormInput; step: number };
        reset({ ...defaults(), ...d.values, consent: false as unknown as true, website: "", instructions: { ...d.values.instructions, hasAudio: false, audioSeconds: 0, audioMime: "" } } as FormInput);
        setStep(Math.min(Math.max(d.step || 1, 1), 5));
      }
    } catch { /* ignore broken draft */ }
    if (!getValues("clientKey")) setValue("clientKey", newKey());
    if (!getValues("startedAt")) setValue("startedAt", Date.now());
    const sub = loadSub();
    if (sub && sub.formspree !== "delivered") { setPartial(sub); setStep(5); }
    setReady(true);
  }, [reset, getValues, setValue]);

  // autosave draft
  useEffect(() => {
    if (!ready) return;
    let t: ReturnType<typeof setTimeout>;
    const sub = watch((values) => {
      clearTimeout(t);
      t = setTimeout(() => {
        try { localStorage.setItem(DRAFT_KEY, JSON.stringify({ values: { ...values, consent: false }, step })); } catch { /* storage full */ }
      }, 500);
    });
    return () => { clearTimeout(t); sub.unsubscribe(); };
  }, [watch, ready, step]);

  const goTo = useCallback((n: number) => { setStep(n); window.scrollTo({ top: 0 }); }, []);

  const next = async () => {
    const ok = await trigger(STEP_FIELDS[step] as never);
    if (ok) goTo(step + 1);
    else document.querySelector<HTMLElement>('[aria-invalid="true"], [role="alert"]')?.scrollIntoView({ block: "center" });
  };

  const markDelivery = async (clientKey: string, formspree: "delivered" | "failed") => {
    for (let i = 0; i < 2; i++) {
      try { const r = await fetch("/api/requests/delivery", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ clientKey, formspree }) }); if (r.ok) return; } catch { /* retry */ }
    }
  };

  const submit = async () => {
    if (lock.current) return; // blocks double taps
    lock.current = true;
    setError(null);
    try {
      let sub = loadSub();
      if (!sub) {
        const assets = attachments.getSnapshot().filter((a) => a.key !== "global-voice").map((a) => ({
          key: a.key, label: a.label, fileName: a.fileName, size: a.blob.size, type: (a.blob.type || "application/octet-stream").slice(0, 100),
          status: "selected-on-device-not-uploaded" as const,
        }));
        const payload = { ...getValues(), assets, website: getValues("website") ?? "" };
        const parsed = formSchema.safeParse(payload);
        if (!parsed.success) { setError(parsed.error.issues[0]?.message ?? "Please check your details."); return; }
        setBusy("saving");
        let res: Response;
        try {
          res = await fetch("/api/requests", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
        } catch {
          setError("Could not reach our server. Nothing was sent. Check your internet connection and try again.");
          return;
        }
        const json = await res.json().catch(() => null);
        if (!res.ok || !json?.ok) {
          setError(json?.message ?? "Something went wrong. Nothing was sent. Please try again.");
          return;
        }
        sub = { requestId: json.requestId, clientKey: parsed.data.clientKey, formspree: "pending", rec: { ...toRecord(parsed.data, json.requestId), status: "new" } };
        saveSub(sub);
      }
      if (sub.formspree !== "delivered") {
        setBusy("sending");
        const r = await sendToFormspree(sub.rec);
        if (!r.ok) {
          sub = { ...sub, formspree: "failed" };
          saveSub(sub);
          void markDelivery(sub.clientKey, "failed");
          setPartial(sub);
          setError(r.message);
          return;
        }
        sub = { ...sub, formspree: "delivered" };
        saveSub(sub);
        await markDelivery(sub.clientKey, "delivered");
      }
      // Both steps genuinely succeeded: only now clear the draft
      try { localStorage.removeItem(DRAFT_KEY); } catch { /* ignore */ }
      router.push(`/request/success?id=${encodeURIComponent(sub.requestId)}`);
    } finally {
      lock.current = false;
      setBusy(null);
    }
  };

  const downloadPackage = async () => {
    if (!partial) return;
    const { blob, name } = await buildRequestPackage(partial.rec, attachments.getSnapshot());
    download(blob, name);
  };

  if (!ready) return <p className="p-6 text-slate-600">Loading…</p>;

  return (
    <FormProvider {...methods}>
      <div className="mx-auto max-w-2xl px-4 pb-32 pt-4">
        <nav aria-label="Progress" className="mb-6">
          <p className="text-sm text-slate-600">Step {step} of 5</p>
          <h1 className="text-2xl font-bold">{TITLES[step - 1]}</h1>
          <div className="mt-3 flex gap-1.5" aria-hidden>
            {TITLES.map((_, i) => <div key={i} className={`h-1.5 flex-1 rounded-full ${i < step ? "bg-brand-600" : "bg-line"}`} />)}
          </div>
        </nav>

        {/* hidden honeypot — real people never see or fill this */}
        <div aria-hidden className="absolute left-[-9999px] h-0 w-0 overflow-hidden">
          <label>Website<input tabIndex={-1} autoComplete="off" {...methods.register("website")} /></label>
        </div>

        {step === 1 && <StepBrand />}
        {step === 2 && <StepBag />}
        {step === 3 && <StepPanels />}
        {step === 4 && <StepInstructions />}
        {step === 5 && <StepReview goTo={goTo} />}

        {error && !partial && <p role="alert" className="mt-5 rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800">{error}</p>}
        {partial && (
          <div role="alert" className="mt-5 space-y-3 rounded-lg border border-amber-300 bg-amber-50 p-4 text-sm">
            <p className="font-semibold">Your request {partial.requestId} is saved, but the message copy was not sent.</p>
            <p>{error ?? "Sending the message copy failed earlier."} Tap “Retry sending”. You will not create a duplicate.</p>
            <div className="flex flex-wrap gap-2">
              <button type="button" className="btn btn-primary" disabled={!!busy} onClick={submit}>{busy ? "Sending…" : "Retry sending"}</button>
              <button type="button" className="btn btn-secondary" onClick={downloadPackage}>Download request package</button>
              <button type="button" className="btn btn-secondary" onClick={() => navigator.clipboard?.writeText(submissionText(partial.rec))}>Copy summary</button>
            </div>
          </div>
        )}

        <div className="fixed inset-x-0 bottom-0 border-t border-line bg-white/95 p-3 backdrop-blur">
          <div className="mx-auto flex max-w-2xl gap-3">
            {step > 1 && <button type="button" className="btn btn-secondary flex-1" onClick={() => goTo(step - 1)} disabled={!!busy || !!partial}>Back</button>}
            {step < 5 && <button type="button" className="btn btn-primary flex-[2]" onClick={next}>Next</button>}
            {step === 5 && !partial && (
              <button type="button" className="btn btn-primary flex-[2]" disabled={!!busy} onClick={async () => { if (await trigger("consent")) void submit(); }}>
                {busy === "saving" ? "Saving your request…" : busy === "sending" ? "Sending…" : "Submit request"}
              </button>
            )}
          </div>
        </div>
      </div>
    </FormProvider>
  );
}
