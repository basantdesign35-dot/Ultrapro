"use client";
import { Controller, useFormContext } from "react-hook-form";
import { Check, Field } from "@/components/ui";
import AudioRecorder from "@/components/AudioRecorder";
import type { FormInput } from "@/lib/schema";

export default function StepInstructions() {
  const { register, control, setValue, formState: { errors } } = useFormContext<FormInput>();
  return (
    <div className="space-y-6">
      <section className="card space-y-3">
        <h2 className="font-semibold">Write your instructions</h2>
        <Field label="Your instructions" htmlFor="written" error={errors.instructions?.written?.message} hint="Hindi, English or Hinglish. Write as much as you like.">
          <textarea id="written" rows={8} className="input" placeholder="Front par logo bada rakhna, left side par address aur right side ko left jaisa rakhna." {...register("instructions.written")} />
        </Field>
      </section>

      <section className="card space-y-3">
        <h2 className="font-semibold">Or record your instructions</h2>
        <p className="text-sm text-slate-600">You can write and record. Both are kept.</p>
        <AudioRecorder
          storeKey="global-voice"
          label="Voice instructions"
          onChange={(info) => {
            setValue("instructions.hasAudio", !!info, { shouldDirty: true });
            setValue("instructions.audioSeconds", info?.seconds ?? 0, { shouldDirty: true });
            setValue("instructions.audioMime", info?.mime ?? "", { shouldDirty: true });
          }}
        />
        <p className="rounded-lg bg-slate-50 p-3 text-xs text-slate-700">
          Your recording stays on this device. This form cannot upload audio. After you submit, you can download a package with your recording and send it to your designer on WhatsApp.
        </p>
      </section>

      <Controller control={control} name="instructions.designerDecidesLayout" render={({ field }) => (
        <Check id="decide" label="Let the designer decide the layout" checked={!!field.value} onChange={(e) => field.onChange(e.target.checked)} />
      )} />
    </div>
  );
}
