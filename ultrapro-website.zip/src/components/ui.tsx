"use client";
import type { ReactNode } from "react";

export function Field({
  label, hint, error, required, htmlFor, children,
}: { label: string; hint?: string; error?: string; required?: boolean; htmlFor?: string; children: ReactNode }) {
  return (
    <div className="space-y-1">
      <label htmlFor={htmlFor} className="block text-sm font-medium">
        {label} {required ? <span className="text-red-600" aria-hidden>*</span> : <span className="font-normal text-slate-500">(optional)</span>}
      </label>
      {hint && <p className="text-xs text-slate-600">{hint}</p>}
      {children}
      {error && <p role="alert" className="text-sm text-red-700">{error}</p>}
    </div>
  );
}

export function Check({ id, label, children, ...rest }: { id: string; label: string; children?: ReactNode } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      <label htmlFor={id} className="flex min-h-[48px] cursor-pointer items-center gap-3 text-base">
        <input id={id} type="checkbox" className="h-6 w-6 shrink-0 accent-[#1f6fd1]" {...rest} />
        <span>{label}</span>
      </label>
      {children}
    </div>
  );
}
