"use client";
import { useState } from "react";

/**
 * Shows the original Ultrapro logo from /public/logo.png (supply the file as-is: do not recolor or resize it
 * in the file). If the file is missing, a plain typeset name is shown so the layout still works.
 * The fallback is NOT the logo.
 */
export default function Logo({ height = 40 }: { height?: number }) {
  const [missing, setMissing] = useState(false);
  if (missing) {
    return (
      <span className="inline-flex flex-col leading-tight">
        <span className="text-xl font-bold tracking-wide text-brand-600">ULTRAPRO</span>
        <span className="text-xs text-slate-600">Paper Bag Company</span>
      </span>
    );
  }
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img src="/logo.png" alt="ULTRAPRO — Paper Bag Company" style={{ height, width: "auto" }} onError={() => setMissing(true)} />
  );
}
