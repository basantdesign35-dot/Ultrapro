"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import Logo from "@/components/Logo";
import { useAuth } from "./AuthProvider";

export default function DesignerShell({ children }: { children: React.ReactNode }) {
  const { user, profile, loading, logout, configured } = useAuth();
  const router = useRouter();
  useEffect(() => { if (!loading && !user) router.replace("/designer/login"); }, [loading, user, router]);

  if (!configured) return <p className="p-6">Firebase is not configured. Copy .env.example to .env.local and fill in the values.</p>;
  if (loading || !user || !profile) return <p className="p-6 text-slate-600">Checking your access…</p>;

  return (
    <div className="min-h-screen">
      <header className="no-print border-b border-line">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3">
          <Link href="/designer" aria-label="Design requests"><Logo height={32} /></Link>
          <nav className="flex items-center gap-4 text-sm">
            <Link href="/designer" className="hover:underline">Requests</Link>
            <Link href="/designer/profile" className="hover:underline">{profile.displayName}</Link>
            <button className="rounded-lg border border-line px-3 py-2" onClick={async () => { await logout(); router.replace("/designer/login"); }}>Sign out</button>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-4 py-6">{children}</main>
    </div>
  );
}
