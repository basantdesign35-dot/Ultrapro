"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { onValue, push, ref, remove, serverTimestamp, update } from "firebase/database";
import JSZip from "jszip";
import { db } from "@/lib/firebase";
import { download } from "@/lib/download";
import { submissionText } from "@/lib/brief";
import type { RequestRecord } from "@/lib/record";
import { useAuth } from "./AuthProvider";
import { useDirectory } from "./useRequests";

interface Note { id: string; authorUid: string; authorName: string; content: string; createdAt?: number; editedAt?: number }
interface Version { id: string; designerUid: string; designerName: string; panel: string; version: string; notes: string; createdAt?: number; fileMetadata: { name: string; size: number; type: string; stored: false; locationNote: string } }

const ALLOWED_EXT = ["png", "jpg", "jpeg", "pdf", "svg", "ai", "cdr", "psd", "eps", "tif", "tiff", "webp", "zip"];
const MAX_LOCAL = 100 * 1024 * 1024;
const PANELS = ["Front", "Back", "Left", "Right", "Full bag"];

function useList<T extends { id: string }>(path: string): { items: T[]; error: string | null } {
  const [items, setItems] = useState<T[]>([]);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => onValue(ref(db(), path), (s) => {
    const v = (s.val() as Record<string, Omit<T, "id">>) ?? {};
    setItems(Object.entries(v).map(([id, x]) => ({ id, ...x }) as T).sort((a, b) => ((a as never as Note).createdAt ?? 0) - ((b as never as Note).createdAt ?? 0)));
    setError(null);
  }, () => setError("Could not load this section (permission or network problem).")), [path]);
  return { items, error };
}

const when = (t?: number) => (t ? new Date(t).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "just now");

export default function Workspace({ rec }: { rec: RequestRecord }) {
  const { user, profile } = useAuth();
  const dir = useDirectory();
  const id = rec.requestId;
  const [msg, setMsg] = useState<string | null>(null);
  const isAdmin = profile?.role === "admin";

  const setField = async (patch: Record<string, unknown>) => {
    setMsg(null);
    try { await update(ref(db(), `designRequests/${id}`), { ...patch, updatedAt: serverTimestamp() }); }
    catch { setMsg("Could not save. You may not have permission, or you are offline."); }
  };

  // ---- notes
  const notes = useList<Note>(`designerNotes/${id}`);
  const [noteText, setNoteText] = useState("");
  const [editing, setEditing] = useState<{ id: string; text: string } | null>(null);
  const addNote = async () => {
    if (!noteText.trim() || !user || !profile) return;
    try {
      await push(ref(db(), `designerNotes/${id}`), { authorUid: user.uid, authorName: profile.displayName, content: noteText.trim().slice(0, 4000), createdAt: serverTimestamp() });
      setNoteText("");
    } catch { setMsg("Could not add the note."); }
  };

  // ---- design versions (metadata only) + local files
  const versions = useList<Version>(`designVersions/${id}`);
  const [local, setLocal] = useState<File[]>([]);
  const [localErr, setLocalErr] = useState<string | null>(null);
  const [previews, setPreviews] = useState<Record<string, string>>({});
  const [vf, setVf] = useState({ panel: "Front", version: "v1", notes: "", fileIndex: -1, location: "" });
  useEffect(() => {
    const urls: Record<string, string> = {};
    local.forEach((f) => { if (f.type.startsWith("image/") && f.type !== "image/svg+xml") urls[f.name + f.size] = URL.createObjectURL(f); });
    setPreviews(urls);
    return () => Object.values(urls).forEach(URL.revokeObjectURL);
  }, [local]);

  const pick = (files: FileList | null) => {
    if (!files) return;
    const ok: File[] = []; const errs: string[] = [];
    Array.from(files).forEach((f) => {
      const ext = f.name.split(".").pop()?.toLowerCase() ?? "";
      if (!ALLOWED_EXT.includes(ext)) errs.push(`${f.name}: type .${ext} is not an approved design format.`);
      else if (f.size > MAX_LOCAL) errs.push(`${f.name}: larger than 100 MB.`);
      else ok.push(f);
    });
    setLocalErr(errs.join(" ") || null);
    setLocal((cur) => [...cur, ...ok]);
  };

  const logVersion = async () => {
    if (!user || !profile) return;
    const f = vf.fileIndex >= 0 ? local[vf.fileIndex] : null;
    if (!f || !vf.version.trim()) { setMsg("Choose a file and enter a version name."); return; }
    try {
      await push(ref(db(), `designVersions/${id}`), {
        designerUid: user.uid, designerName: profile.displayName, panel: vf.panel, version: vf.version.trim().slice(0, 40), notes: vf.notes.slice(0, 2000),
        fileMetadata: { name: f.name.slice(0, 200), size: f.size, type: (f.type || "unknown").slice(0, 100), stored: false, locationNote: vf.location.slice(0, 300) },
        createdAt: serverTimestamp(),
      });
      setVf({ ...vf, notes: "", location: "" });
    } catch { setMsg("Could not log the version."); }
  };

  const exportPackage = async () => {
    const zip = new JSZip();
    zip.file("brief.txt", submissionText(rec));
    zip.file("manifest.json", JSON.stringify({ requestId: id, exportedBy: profile?.displayName, exportedAt: new Date().toISOString(), versions: versions.items.map(({ id: _i, ...v }) => v), files: local.map((f) => ({ name: f.name, size: f.size })) }, null, 2));
    const folder = zip.folder("designs");
    local.forEach((f) => folder?.file(f.name, f));
    download(await zip.generateAsync({ type: "blob" }), `ultrapro-${id}-design-package.zip`);
  };

  // ---- client voice note: local playback only
  const [voiceUrl, setVoiceUrl] = useState<string | null>(null);
  const voiceRef = useRef<HTMLInputElement>(null);

  const designerOptions = useMemo(() => Object.entries(dir).filter(([uid]) => isAdmin || uid === user?.uid), [dir, isAdmin, user]);

  return (
    <section className="no-print space-y-6" aria-labelledby="ws">
      <h2 id="ws" className="text-xl font-bold">Designer workspace</h2>
      {msg && <p role="alert" className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800">{msg}</p>}

      <div className="card grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="st" className="mb-1 block text-sm font-medium">Status</label>
          <select id="st" className="input" value={rec.status} onChange={(e) => setField({ status: e.target.value })}>
            <option value="new">New</option><option value="in_progress">In Progress</option><option value="completed">Completed</option>
          </select>
        </div>
        <div>
          <label htmlFor="as" className="mb-1 block text-sm font-medium">Assigned designer</label>
          <select id="as" className="input" value={rec.assignedDesignerUid ?? ""} onChange={(e) => setField({ assignedDesignerUid: e.target.value })}>
            <option value="">Unassigned</option>
            {designerOptions.map(([uid, d]) => <option key={uid} value={uid}>{d.displayName}{uid === user?.uid ? " (me)" : ""}</option>)}
          </select>
        </div>
      </div>

      <div className="card space-y-3">
        <h3 className="font-semibold">Client voice note</h3>
        {rec.audio.recordedByClient
          ? <p className="text-sm">The client recorded {rec.audio.seconds}s of audio. It is <strong>not stored</strong> in this system. Ask them to send it on WhatsApp, then you can play it here (on this device only).</p>
          : <p className="text-sm text-slate-600">The client did not record a voice note.</p>}
        <input ref={voiceRef} type="file" accept="audio/*" className="block text-sm" onChange={(e) => { const f = e.target.files?.[0]; setVoiceUrl(f ? URL.createObjectURL(f) : null); }} />
        {voiceUrl && <audio controls src={voiceUrl} className="w-full" />}
      </div>

      <div className="card space-y-3">
        <h3 className="font-semibold">Internal notes</h3>
        {notes.error && <p className="text-sm text-red-700">{notes.error}</p>}
        <ul className="space-y-2">
          {notes.items.map((n) => (
            <li key={n.id} className="rounded-lg bg-slate-50 p-3 text-sm">
              <p className="text-xs text-slate-500">{n.authorName} · {when(n.createdAt)}{n.editedAt ? " · edited" : ""}</p>
              {editing?.id === n.id ? (
                <div className="mt-2 space-y-2">
                  <textarea className="input" rows={3} value={editing.text} onChange={(e) => setEditing({ id: n.id, text: e.target.value })} />
                  <div className="flex gap-2">
                    <button className="btn btn-primary min-h-[40px] px-4 text-sm" onClick={async () => { await update(ref(db(), `designerNotes/${id}/${n.id}`), { content: editing.text.trim().slice(0, 4000), editedAt: serverTimestamp() }).catch(() => setMsg("Could not edit this note.")); setEditing(null); }}>Save</button>
                    <button className="btn btn-secondary min-h-[40px] px-4 text-sm" onClick={() => setEditing(null)}>Cancel</button>
                  </div>
                </div>
              ) : (
                <>
                  <p className="mt-1 whitespace-pre-wrap">{n.content}</p>
                  {(n.authorUid === user?.uid || isAdmin) && (
                    <div className="mt-2 flex gap-3 text-xs">
                      <button className="text-brand-600 underline" onClick={() => setEditing({ id: n.id, text: n.content })}>Edit</button>
                      <button className="text-red-700 underline" onClick={async () => { if (confirm("Delete this note?")) await remove(ref(db(), `designerNotes/${id}/${n.id}`)).catch(() => setMsg("Could not delete this note.")); }}>Delete</button>
                    </div>
                  )}
                </>
              )}
            </li>
          ))}
        </ul>
        <textarea className="input" rows={3} placeholder="Add an internal note" aria-label="New note" value={noteText} onChange={(e) => setNoteText(e.target.value)} />
        <button className="btn btn-primary" onClick={addNote} disabled={!noteText.trim()}>Add note</button>
      </div>

      <div className="card space-y-4">
        <h3 className="font-semibold">Upload Your Design</h3>
        <p className="rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm">
          <strong>Permanent file storage is not set up.</strong> Formspree Free is not a private file store and Firebase Storage has not been approved. Files you choose here stay in this browser tab for preview and for exporting a package. You can log a version note so the team knows what exists and where it is saved. A logged note is <strong>not</strong> an uploaded file.
        </p>
        <input type="file" multiple className="block min-h-[48px] w-full rounded-lg border border-line p-2 text-sm" aria-label="Choose design files" onChange={(e) => { pick(e.target.files); e.target.value = ""; }} />
        {localErr && <p role="alert" className="text-sm text-red-700">{localErr}</p>}
        {local.length > 0 && (
          <ul className="grid gap-3 sm:grid-cols-2">
            {local.map((f, i) => (
              <li key={f.name + f.size + i} className="flex items-center gap-3 rounded-lg border border-line p-2 text-sm">
                {previews[f.name + f.size] ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={previews[f.name + f.size]} alt="" className="h-14 w-14 rounded object-cover" /> : <span className="grid h-14 w-14 place-items-center rounded bg-slate-100 text-xs uppercase">{f.name.split(".").pop()}</span>}
                <span className="min-w-0 flex-1"><span className="block truncate">{f.name}</span><span className="text-xs text-slate-500">{(f.size / 1024).toFixed(0)} KB · local only</span></span>
                <button className="text-xs text-red-700 underline" onClick={() => setLocal((c) => c.filter((_, j) => j !== i))}>Remove</button>
              </li>
            ))}
          </ul>
        )}
        {local.length > 0 && <button className="btn btn-secondary" onClick={exportPackage}>Export design package (.zip)</button>}

        <div className="space-y-3 border-t border-line pt-4">
          <h4 className="text-sm font-semibold">Log a design version (note only, file is not stored)</h4>
          <div className="grid gap-3 sm:grid-cols-3">
            <select className="input" aria-label="Panel" value={vf.panel} onChange={(e) => setVf({ ...vf, panel: e.target.value })}>{PANELS.map((p) => <option key={p}>{p}</option>)}</select>
            <input className="input" aria-label="Version" placeholder="Version, e.g. v1" value={vf.version} onChange={(e) => setVf({ ...vf, version: e.target.value })} />
            <select className="input" aria-label="File" value={vf.fileIndex} onChange={(e) => setVf({ ...vf, fileIndex: Number(e.target.value) })}>
              <option value={-1}>Choose a file above</option>{local.map((f, i) => <option key={i} value={i}>{f.name}</option>)}
            </select>
          </div>
          <input className="input" aria-label="Where is the file saved" placeholder="Where is the file saved? (e.g. shared drive path)" value={vf.location} onChange={(e) => setVf({ ...vf, location: e.target.value })} />
          <textarea className="input" rows={2} aria-label="Designer notes" placeholder="Designer notes" value={vf.notes} onChange={(e) => setVf({ ...vf, notes: e.target.value })} />
          <button className="btn btn-primary" onClick={logVersion}>Log version</button>
        </div>
        {versions.error && <p className="text-sm text-red-700">{versions.error}</p>}
        {versions.items.length > 0 && (
          <ul className="divide-y divide-line text-sm">
            {versions.items.map((v) => (
              <li key={v.id} className="py-2">
                <p><strong>{v.panel}</strong> · {v.version} · {v.fileMetadata.name} <span className="rounded bg-slate-100 px-1.5 py-0.5 text-xs">file not stored</span></p>
                <p className="text-xs text-slate-500">{v.designerName} · {when(v.createdAt)}{v.fileMetadata.locationNote ? ` · saved at: ${v.fileMetadata.locationNote}` : ""}</p>
                {v.notes && <p className="mt-1 whitespace-pre-wrap">{v.notes}</p>}
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
