"use client";
import { useEffect, useState } from "react";
import { onValue, ref } from "firebase/database";
import { db } from "@/lib/firebase";
import type { RequestRecord } from "@/lib/record";

export type Designers = Record<string, { displayName: string }>;

export function useDirectory() {
  const [dir, setDir] = useState<Designers>({});
  useEffect(() => onValue(ref(db(), "designerDirectory"), (s) => setDir((s.val() as Designers) ?? {}), () => setDir({})), []);
  return dir;
}

export function useRequests() {
  const [items, setItems] = useState<RequestRecord[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => onValue(
    ref(db(), "designRequests"),
    (s) => { const v = (s.val() as Record<string, RequestRecord>) ?? {}; setItems(Object.values(v).sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0))); setError(null); },
    (e) => setError(e.message.includes("permission") ? "You do not have permission to view requests. Ask an administrator to check your account." : "Could not load requests. Check your connection."),
  ), []);
  return { items, error };
}
