"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import {
  browserLocalPersistence, browserSessionPersistence, onAuthStateChanged, sendPasswordResetEmail,
  setPersistence, signInWithEmailAndPassword, signOut, type User,
} from "firebase/auth";
import { get, ref } from "firebase/database";
import { auth, db, firebaseConfigured } from "@/lib/firebase";

export interface DesignerProfile { displayName: string; email: string; role: "designer" | "admin"; active: boolean }

interface Ctx {
  user: User | null;
  profile: DesignerProfile | null;
  loading: boolean;
  configured: boolean;
  signIn: (email: string, password: string, remember: boolean) => Promise<string | null>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<string | null>;
}
const AuthCtx = createContext<Ctx | null>(null);
export const useAuth = () => { const c = useContext(AuthCtx); if (!c) throw new Error("AuthProvider missing"); return c; };

function friendly(code: string | undefined) {
  switch (code) {
    case "auth/invalid-credential": case "auth/wrong-password": case "auth/user-not-found": return "Email or password is incorrect.";
    case "auth/invalid-email": return "Enter a valid email address.";
    case "auth/user-disabled": return "This account has been disabled. Contact your administrator.";
    case "auth/too-many-requests": return "Too many attempts. Wait a few minutes or reset your password.";
    case "auth/network-request-failed": return "Network problem. Check your connection and try again.";
    default: return "Could not sign in. Please try again.";
  }
}

export default function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<DesignerProfile | null>(null);
  const [loading, setLoading] = useState(firebaseConfigured);

  useEffect(() => {
    if (!firebaseConfigured) return;
    return onAuthStateChanged(auth(), async (u) => {
      if (!u) { setUser(null); setProfile(null); setLoading(false); return; }
      try {
        const snap = await get(ref(db(), `designerProfiles/${u.uid}`));
        const p = snap.val() as DesignerProfile | null;
        if (!p || p.active !== true) { await signOut(auth()); setUser(null); setProfile(null); }
        else { setUser(u); setProfile(p); }
      } catch {
        await signOut(auth());
        setUser(null); setProfile(null);
      }
      setLoading(false);
    });
  }, []);

  const signIn = useCallback(async (email: string, password: string, remember: boolean) => {
    try {
      await setPersistence(auth(), remember ? browserLocalPersistence : browserSessionPersistence);
      const cred = await signInWithEmailAndPassword(auth(), email.trim(), password);
      const snap = await get(ref(db(), `designerProfiles/${cred.user.uid}`));
      const p = snap.val() as DesignerProfile | null;
      if (!p || p.active !== true) {
        await signOut(auth());
        return "This account is not approved for the designer workspace. Contact your administrator.";
      }
      return null;
    } catch (e) {
      return friendly((e as { code?: string }).code);
    }
  }, []);

  const logout = useCallback(async () => { await signOut(auth()); }, []);
  const resetPassword = useCallback(async (email: string) => {
    try { await sendPasswordResetEmail(auth(), email.trim()); return null; }
    catch (e) {
      const code = (e as { code?: string }).code;
      // do not reveal whether an account exists
      if (code === "auth/user-not-found") return null;
      return friendly(code);
    }
  }, []);

  const value = useMemo(() => ({ user, profile, loading, configured: firebaseConfigured, signIn, logout, resetPassword }), [user, profile, loading, signIn, logout, resetPassword]);
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}
