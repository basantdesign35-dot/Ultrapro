"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { attachments, extFromMime } from "@/lib/attachments";
import { useAttachments } from "@/lib/useAttachments";
import { download } from "@/lib/download";

type State = "idle" | "requesting" | "recording" | "paused" | "denied" | "unsupported" | "error";

const CANDIDATES = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg;codecs=opus", "audio/ogg"];

function pickMime(): string | undefined {
  if (typeof MediaRecorder === "undefined") return undefined;
  if (typeof MediaRecorder.isTypeSupported !== "function") return "";
  return CANDIDATES.find((m) => MediaRecorder.isTypeSupported(m)) ?? "";
}

const fmt = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

export default function AudioRecorder({
  storeKey,
  label,
  onChange,
}: {
  storeKey: string;
  label: string;
  /** called when a recording is saved (seconds, mime) or removed (null) */
  onChange: (info: { seconds: number; mime: string } | null) => void;
}) {
  const all = useAttachments();
  const saved = all.find((a) => a.key === storeKey);
  const [state, setState] = useState<State>("idle");
  const [seconds, setSeconds] = useState(0);
  const [url, setUrl] = useState<string | null>(null);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const secRef = useRef(0);
  const canPause = typeof MediaRecorder !== "undefined" && typeof MediaRecorder.prototype?.pause === "function";

  const supported =
    typeof window !== "undefined" && !!navigator.mediaDevices?.getUserMedia && typeof MediaRecorder !== "undefined";

  useEffect(() => {
    if (!saved) { setUrl(null); return; }
    const u = URL.createObjectURL(saved.blob);
    setUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [saved]);

  const stopTimer = () => { if (timer.current) clearInterval(timer.current); timer.current = null; };
  const stopStream = () => { streamRef.current?.getTracks().forEach((t) => t.stop()); streamRef.current = null; };

  useEffect(() => () => { stopTimer(); stopStream(); }, []);

  const start = useCallback(async () => {
    if (!supported) { setState("unsupported"); return; }
    setState("requesting");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const mime = pickMime();
      const rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
      chunks.current = [];
      secRef.current = 0;
      setSeconds(0);
      rec.ondataavailable = (e) => { if (e.data.size > 0) chunks.current.push(e.data); };
      rec.onstop = () => {
        stopTimer();
        stopStream();
        const type = rec.mimeType || mime || "audio/webm";
        const blob = new Blob(chunks.current, { type });
        if (blob.size === 0) { setState("error"); return; }
        attachments.set({
          key: storeKey, label, blob, kind: "audio", seconds: secRef.current,
          fileName: `${storeKey}.${extFromMime(type)}`,
        });
        onChange({ seconds: secRef.current, mime: type });
        setState("idle");
      };
      rec.onerror = () => { stopTimer(); stopStream(); setState("error"); };
      rec.start(1000);
      recRef.current = rec;
      timer.current = setInterval(() => { secRef.current += 1; setSeconds(secRef.current); }, 1000);
      setState("recording");
    } catch (e) {
      stopStream();
      const name = (e as DOMException)?.name;
      setState(name === "NotAllowedError" || name === "SecurityError" ? "denied" : name === "NotFoundError" ? "error" : "error");
    }
  }, [supported, storeKey, label, onChange]);

  const pauseResume = () => {
    const rec = recRef.current;
    if (!rec) return;
    if (rec.state === "recording") { rec.pause(); stopTimer(); setState("paused"); }
    else if (rec.state === "paused") {
      rec.resume();
      timer.current = setInterval(() => { secRef.current += 1; setSeconds(secRef.current); }, 1000);
      setState("recording");
    }
  };
  const stop = () => { if (recRef.current && recRef.current.state !== "inactive") recRef.current.stop(); };
  const remove = () => { attachments.remove(storeKey); onChange(null); setSeconds(0); };

  const btn = "min-h-[48px] rounded-lg px-4 text-base font-medium";

  if (state === "unsupported" || (!supported && typeof window !== "undefined")) {
    return (
      <p role="status" className="rounded-lg border border-line bg-slate-50 p-3 text-sm text-slate-700">
        Voice recording is not available in this browser. Please type your instructions instead, or open this page in Chrome or Safari.
      </p>
    );
  }

  return (
    <div className="space-y-3">
      {state === "denied" && (
        <p role="alert" className="rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          Microphone access was blocked. Allow the microphone for this site in your browser settings and try again, or type your instructions instead.
        </p>
      )}
      {state === "error" && (
        <p role="alert" className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800">
          Recording did not work (no microphone found, or nothing was captured). Please try again or type your instructions.
        </p>
      )}

      {(state === "recording" || state === "paused") && (
        <div className="flex flex-wrap items-center gap-3">
          <span className="inline-flex items-center gap-2 text-lg font-semibold tabular-nums" aria-live="polite">
            <span className={`h-3 w-3 rounded-full ${state === "recording" ? "animate-pulse bg-red-600" : "bg-slate-400"}`} />
            {fmt(seconds)} {state === "paused" && <span className="text-sm font-normal text-slate-600">Paused</span>}
          </span>
          {canPause && (
            <button type="button" onClick={pauseResume} className={`${btn} border border-line bg-white`}>
              {state === "paused" ? "Resume" : "Pause"}
            </button>
          )}
          <button type="button" onClick={stop} className={`${btn} bg-brand-600 text-white`}>Stop and save</button>
        </div>
      )}

      {state === "requesting" && <p className="text-sm text-slate-600">Waiting for microphone permission…</p>}

      {(state === "idle" || state === "denied" || state === "error") && !saved && (
        <button type="button" onClick={start} className={`${btn} bg-brand-600 text-white`}>Start recording</button>
      )}

      {saved && state === "idle" && url && (
        <div className="space-y-2 rounded-lg border border-line p-3">
          <p className="text-sm font-medium">Recording saved on this device · {fmt(saved.seconds ?? 0)}</p>
          <audio controls src={url} className="w-full" />
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => { remove(); void start(); }} className={`${btn} border border-line bg-white`}>Record again</button>
            <button type="button" onClick={() => download(saved.blob, saved.fileName)} className={`${btn} border border-line bg-white`}>Download</button>
            <button type="button" onClick={remove} className={`${btn} border border-red-200 bg-white text-red-700`}>Delete</button>
          </div>
        </div>
      )}
    </div>
  );
}
